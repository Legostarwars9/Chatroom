#!/usr/bin/env node
'use strict';

/*
 * BREAKWATER ROYALE — one-file browser battle royale.
 * Run with Node.js 18 or newer: node breakwater.js
 * Open http://localhost:3000. Share one HTTPS reverse proxy/tunnel URL for internet play.
 * Find Match starts a public queue with a 14-second boarding window. Private Room
 * gives you a code; the room creator launches it. Up to 8 humans share 12 seats
 * with bots. Solo Practice runs locally and starts immediately.
 *
 * WASD move, Shift sprint, Space jump, mouse look, left click shoot, right click aim.
 * 1/2 select guns, R reloads, 3 then fire drinks a shield tonic. E opens a crate,
 * F harvests trees. Q toggles building; Z/X/C select wall/ramp/floor, click places.
 * M opens the map; P or Esc opens the field menu. Touch controls appear on phones.
 *
 * Optional: PORT=8080 HOST=127.0.0.1 node breakwater.js
 * Optional coturn / hosted TURN: TURN_URLS='turn:relay.example:3478,turns:relay.example:5349'
 * and either TURN_SECRET (coturn REST shared secret), or TURN_USER and TURN_PASS.
 * Example with an existing service (replace the sample host and credentials):
 * TURN_URLS='turn:relay.example:3478' TURN_USER='player' TURN_PASS='password' node breakwater.js
 * STUN_URLS can be a comma-separated list. Set it to an empty string for LAN-only ICE.
 * ICE_POLICY=relay forces TURN for diagnosing networks. Do not distribute TURN_SECRET.
 *
 * Ordinary JSON requests handle matchmaking and WebRTC signaling. The first
 * browser in each match runs the simulation. Guests use an ordered reliable control
 * channel and an unordered, non-retransmitted channel for input and world snapshots.
 * Host departure ends a live round. Rooms and sessions are held in memory on one node.
 * All models, terrain, sound effects, interface elements, and shaders are built here.
 */

const http = require('node:http');
const crypto = require('node:crypto');

function createMatchmaker(options = {}) {
  const rooms = new Map();
  const sessions = new Map();
  const capacity = 8;
  const queueMs = options.queueMs ?? 14000;
  const env = options.env || process.env;
  const splitUrls = (value) =>
    (value || '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
  const clientScript =
    [makeIsland, makeMechanics, makeSimulation, makeRenderer, browserGame]
      .map((fn) => fn.toString())
      .join('\n') + '\nbrowserGame();\n';
  const html = gamePage();
  const codeAlphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const rand = (bytes) => crypto.randomBytes(bytes).toString('hex');
  const publicPlayer = (p) => ({ id: p.id, name: p.name });
  function iceConfig(id) {
    const iceServers = [];
    const stun = splitUrls(env.STUN_URLS ?? 'stun:stun.l.google.com:19302');
    if (stun.length) iceServers.push({ urls: stun });
    const urls = splitUrls(env.TURN_URLS);
    if (urls.length) {
      if (env.TURN_SECRET) {
        const username = Math.floor(Date.now() / 1000 + 6 * 3600) + ':' + id;
        iceServers.push({
          urls,
          username,
          credential: crypto.createHmac('sha1', env.TURN_SECRET).update(username).digest('base64'),
        });
      } else if (env.TURN_USER && env.TURN_PASS) {
        iceServers.push({ urls, username: env.TURN_USER, credential: env.TURN_PASS });
      }
    }
    return { iceServers, iceTransportPolicy: env.ICE_POLICY === 'relay' ? 'relay' : 'all' };
  }
  // Older clients still consume these same events over the original SSE endpoint.
  function streamEvent(res, event) {
    res.write('id: ' + event.seq + '\ndata: ' + JSON.stringify(event) + '\n\n');
  }
  function emit(p, type, data) {
    const event = { seq: ++p.seq, type, data };
    p.events.push(event);
    if (p.events.length > 400) p.events.shift();
    if (p.stream && !p.stream.destroyed) streamEvent(p.stream, event);
    p.flushPoll?.();
  }
  function poll(p, after, res) {
    if (!Number.isSafeInteger(after) || after < 0) fail(400, 'Invalid event cursor.');
    if (after > p.seq || after < p.events[0].seq - 1) fail(409, 'Lobby updates expired. Join again.');
    // The client acknowledges events with its next cursor. A lost response can be replayed.
    if (p.room && !p.stream) p.expires = Date.now() + 30000;
    p.flushPoll?.();
    const send = () => reply(res, 200, { events: p.events.filter((event) => event.seq > after) });
    if (p.seq > after) return send();
    if (!p.room) fail(410, 'This room has ended.');

    function clear() {
      clearTimeout(timer);
      if (p.flushPoll === flush) p.flushPoll = null;
      res.off('close', clear);
    }
    function flush() {
      clear();
      if (!res.destroyed && !res.writableEnded) send();
    }
    const timer = setTimeout(flush, 8000);
    p.flushPoll = flush;
    res.once('close', clear);
  }
  function broadcast(room, type, data) {
    for (const id of room.ids) {
      const p = sessions.get(id);
      if (p) emit(p, type, data);
    }
  }
  function lobby(room) {
    broadcast(room, 'lobby', {
      code: room.code,
      private: room.private,
      host: room.host,
      players: room.ids.map((id) => publicPlayer(sessions.get(id))),
      wait: Math.max(0, room.deadline - Date.now()),
    });
  }
  function lock(room) {
    if (room.phase !== 'queue' || !room.ids.length) return;
    room.phase = 'links';
    room.deadline = Date.now() + 35000;
    broadcast(room, 'pair', {
      host: room.host,
      seed: room.seed,
      players: room.ids.map((id) => publicPlayer(sessions.get(id))),
    });
  }
  function terminate(room, reason) {
    broadcast(room, 'closed', { reason });
    for (const id of room.ids) {
      const p = sessions.get(id);
      if (p) {
        p.room = null;
        p.expires = Date.now() + 15000;
      }
    }
    rooms.delete(room.code);
  }
  function remove(p) {
    if (!sessions.has(p.id)) return;
    const r = rooms.get(p.room);
    sessions.delete(p.id);
    if (p.stream) p.stream.end();
    p.flushPoll?.();
    if (!r) return;
    r.ids = r.ids.filter((id) => id !== p.id);
    if (!r.ids.length) {
      rooms.delete(r.code);
      return;
    }
    if (r.phase === 'queue') {
      r.host = r.ids[0];
      lobby(r);
      return;
    }
    if (r.host === p.id) {
      terminate(r, 'The match host left. Queue again to drop with a new host.');
      return;
    }
    broadcast(r, 'depart', { id: p.id });
  }
  function newRoom(isPrivate) {
    let code;
    do {
      code = Array.from(crypto.randomBytes(6), (n) => codeAlphabet[n % codeAlphabet.length]).join('');
    } while (rooms.has(code));
    const r = {
      code,
      private: isPrivate,
      phase: 'queue',
      ids: [],
      host: null,
      seed: crypto.randomBytes(4).readUInt32LE(),
      deadline: isPrivate ? 0 : Date.now() + queueMs,
    };
    rooms.set(code, r);
    return r;
  }
  function reply(res, status, data) {
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
    });
    res.end(JSON.stringify(data));
  }
  function fail(status, message) {
    const e = new Error(message);
    e.status = status;
    throw e;
  }
  async function body(req) {
    if (!(req.headers['content-type'] || '').startsWith('application/json')) fail(415, 'Send JSON.');
    let bytes = 0;
    const chunks = [];
    for await (const chunk of req) {
      bytes += chunk.length;
      if (bytes > 32768) fail(413, 'Message is too large.');
      chunks.push(chunk);
    }
    try {
      const x = JSON.parse(Buffer.concat(chunks).toString());
      if (x && typeof x === 'object' && !Array.isArray(x)) return x;
    } catch {}
    fail(400, 'Invalid JSON object.');
  }
  function auth(id, token) {
    const p = sessions.get(id);
    if (!p || typeof token !== 'string' || token !== p.token) fail(403, 'Session expired. Join again.');
    return p;
  }
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('Referrer-Policy', 'no-referrer');
      if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/game.js')) {
        const js = url.pathname === '/game.js';
        res.writeHead(200, {
          'Content-Type': js ? 'text/javascript; charset=utf-8' : 'text/html; charset=utf-8',
          'Cache-Control': 'no-cache',
        });
        return res.end(js ? clientScript : html);
      }
      if (req.method === 'GET' && url.pathname === '/health')
        return reply(res, 200, { ok: true, matchmaking: 'http-poll' });
      if (req.method === 'GET' && url.pathname === '/events') {
        const p = auth(url.searchParams.get('id'), url.searchParams.get('ticket'));
        const last = Number(req.headers['last-event-id'] || 0);
        if (p.stream) p.stream.end();
        res.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache, no-transform',
          'X-Accel-Buffering': 'no',
          Connection: 'keep-alive',
        });
        res.write('retry: 1200\n: connected\n\n');
        p.stream = res;
        p.expires = Infinity;
        for (const event of p.events) if (event.seq > last) streamEvent(res, event);
        res.on('close', () => {
          if (p.stream === res) {
            p.stream = null;
            p.expires = Date.now() + 18000;
          }
        });
        return;
      }
      if (req.method !== 'POST' || !url.pathname.startsWith('/api/'))
        return reply(res, 404, { error: 'Unknown route.' });
      if (req.headers['sec-fetch-site'] === 'cross-site') fail(403, 'Use the same game origin.');
      const x = await body(req);
      if (url.pathname === '/api/join') {
        if (sessions.size >= 384) fail(503, 'Matchmaker is full. Try again shortly.');
        if (!['public', 'create', 'code'].includes(x.mode)) fail(400, 'Unknown queue.');
        let r;
        if (x.mode === 'code') {
          r = rooms.get(String(x.code).toUpperCase().trim());
          if (!r || !r.private || r.phase !== 'queue')
            fail(404, 'That room is unavailable or has already launched.');
          if (r.ids.length >= capacity) fail(409, 'That room is full.');
        } else if (x.mode === 'create') r = newRoom(true);
        else
          r =
            [...rooms.values()].find((a) => !a.private && a.phase === 'queue' && a.ids.length < capacity) ||
            newRoom(false);
        const name =
          String(x.name || '')
            .normalize('NFKC')
            .replace(/[^\p{L}\p{N} _.-]/gu, '')
            .trim()
            .slice(0, 16) || 'Drifter';
        const p = {
          id: rand(5),
          token: rand(20),
          name,
          room: r.code,
          seq: 0,
          events: [],
          stream: null,
          flushPoll: null,
          expires: Date.now() + 18000,
          window: 0,
          count: 0,
        };
        sessions.set(p.id, p);
        r.ids.push(p.id);
        r.host ||= p.id;
        lobby(r);
        if (!r.private && r.ids.length === capacity) lock(r);
        return reply(res, 201, { id: p.id, token: p.token, ice: iceConfig(p.id), events: p.events });
      }
      const p = auth(x.id, x.token);
      // Closed-room events must remain readable after the room itself is removed.
      if (url.pathname === '/api/poll') return poll(p, x.after, res);
      if (url.pathname === '/api/leave') {
        remove(p);
        return reply(res, 200, { ok: true });
      }
      const r = rooms.get(p.room);
      if (!r) fail(410, 'This room has ended.');
      if (url.pathname === '/api/launch') {
        if (r.host !== p.id || !r.private || r.phase !== 'queue')
          fail(409, 'Only the waiting room host can launch.');
        lock(r);
      } else if (url.pathname === '/api/start') {
        if (r.host !== p.id || r.phase !== 'links' || !Array.isArray(x.active))
          fail(409, 'Match cannot start.');
        const kept = r.ids.filter((id) => id === p.id || x.active.includes(id));
        for (const id of r.ids.filter((id) => !kept.includes(id))) {
          const cut = sessions.get(id);
          cut.room = null;
          cut.expires = Date.now() + 15000;
          emit(cut, 'closed', {
            reason:
              'Could not connect to the host over WebRTC. Try again, or ask the server operator to configure TURN.',
          });
        }
        r.ids = kept;
        r.phase = 'live';
        return reply(res, 200, { players: kept.map((id) => publicPlayer(sessions.get(id))) });
      } else if (url.pathname === '/api/signal') {
        const target = sessions.get(x.to);
        if (
          !target ||
          target.id === p.id ||
          target.room !== r.code ||
          (p.id !== r.host && target.id !== r.host) ||
          r.phase === 'queue'
        )
          fail(409, 'Peer unavailable.');
        const now = Date.now();
        if (now - p.window > 1000) {
          p.window = now;
          p.count = 0;
        }
        if (++p.count > 220) fail(429, 'Slow down.');
        const d = x.signal;
        if (!d || typeof d !== 'object') fail(400, 'Invalid signal.');
        if (d.description) {
          if (
            d.description.type !== (p.id === r.host ? 'offer' : 'answer') ||
            typeof d.description.sdp !== 'string' ||
            d.description.sdp.length > 24576
          )
            fail(400, 'Invalid session description.');
          emit(target, 'wire', {
            from: p.id,
            signal: { description: { type: d.description.type, sdp: d.description.sdp } },
          });
        } else {
          const c = d.candidate;
          if (!c || typeof c.candidate !== 'string' || c.candidate.length > 2048)
            fail(400, 'Invalid ICE candidate.');
          emit(target, 'wire', {
            from: p.id,
            signal: {
              candidate: {
                candidate: c.candidate,
                sdpMid: c.sdpMid,
                sdpMLineIndex: c.sdpMLineIndex,
                usernameFragment: c.usernameFragment,
              },
            },
          });
        }
      } else return reply(res, 404, { error: 'Unknown route.' });
      reply(res, 200, { ok: true });
    } catch (e) {
      if (!res.headersSent && !res.destroyed)
        reply(res, e.status || 500, { error: e.status ? e.message : 'Server error.' });
    }
  });
  let heart = 0;
  const sweep = setInterval(() => {
    const now = Date.now();
    for (const p of sessions.values()) if (p.expires <= now) remove(p);
    for (const r of rooms.values()) {
      if (r.phase === 'queue' && !r.private && now >= r.deadline) lock(r);
      else if (r.phase === 'links' && now >= r.deadline)
        terminate(r, 'The host did not start the match. Please queue again.');
    }
    if (++heart % 20 === 0)
      for (const p of sessions.values()) if (p.stream) p.stream.write(': heartbeat\n\n');
  }, 500);
  sweep.unref();
  server.on('close', () => clearInterval(sweep));
  return server;
}

/* Deterministic island, shared by simulation, renderer, and minimap. Coordinates are metres. */
function makeIsland(seed) {
  const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
  function random(s) {
    return () => {
      s = (s + 0x6d2b79f5) | 0;
      let t = Math.imul(s ^ (s >>> 15), 1 | s);
      t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const rng = random(seed | 0),
    phase = rng() * 6.28,
    phase2 = rng() * 6.28;
  const n = 80,
    step = 4,
    edge = (n * step) / 2,
    heights = new Float32Array((n + 1) * (n + 1));
  const hills = [
    [-43, 40, 21, 900],
    [37, 31, 13, 620],
    [61, 64, 16, 450],
    [-69, -24, 10, 570],
    [-4, -63, 12, 540],
    [8, -1, 7, 900],
  ];
  function elevation(x, z) {
    const angle = Math.atan2(z, x),
      coast = 121 + 7 * Math.sin(angle * 3 + phase) + 4 * Math.sin(angle * 7 + phase2);
    const land = coast - Math.hypot(x, z);
    if (land < 0) return Math.max(-9, land * 0.48);
    let h =
      2.8 + 1.3 * Math.sin(x * 0.077 + phase) * Math.cos(z * 0.065) + 0.7 * Math.sin(z * 0.112 + phase2);
    for (const [cx, cz, size, width] of hills)
      h += size * Math.exp(-((x - cx) ** 2 + (z - cz) ** 2) / width);
    return Math.min(land * 0.26, h * clamp(land / 17, 0, 1) + land * 0.01);
  }
  const huts = [
    [-50, 8, 9, 7, 0],
    [-35, 17, 7, 6, 1],
    [-59, -3, 6, 5, 2],
    [21, -58, 8, 6, 1],
    [35, -61, 8, 5, 0],
    [26, -45, 6, 5, 2],
    [50, 51, 7, 6, 0],
    [69, 50, 5, 5, 1],
    [-7, 56, 6, 5, 2],
    [58, -17, 7, 5, 0],
  ];
  const pads = [...huts, [63, 63, 7, 7]].map(([x, z, w, d]) => ({ x, z, w, d, y: elevation(x, z) }));
  for (let j = 0; j <= n; j++)
    for (let i = 0; i <= n; i++) {
      const x = i * step - edge,
        z = j * step - edge;
      let y = elevation(x, z);
      for (const p of pads) {
        const outside = Math.max(Math.abs(x - p.x) - p.w / 2 - 1, Math.abs(z - p.z) - p.d / 2 - 1);
        if (outside < 6) {
          const u = clamp(1 - outside / 6, 0, 1);
          y += (p.y - y) * u * u * (3 - 2 * u);
        }
      }
      heights[j * (n + 1) + i] = y;
    }
  function ground(x, z) {
    const u = clamp((x + edge) / step, 0, n - 0.00001),
      v = clamp((z + edge) / step, 0, n - 0.00001);
    const i = Math.floor(u),
      j = Math.floor(v),
      a = u - i,
      b = v - j,
      offset = j * (n + 1) + i;
    const h = heights[offset],
      e = heights[offset + 1],
      s = heights[offset + n + 1],
      d = heights[offset + n + 2];
    return a > b ? h + (e - h) * a + (d - e) * b : h + (d - s) * a + (s - h) * b;
  }
  const pois = [
    { x: 63, z: 62, name: 'RELAY POINT' },
    { x: -48, z: 7, name: 'PINE YARD' },
    { x: 23, z: -58, name: 'CINDER CAMP' },
  ];
  const paths = [
    [
      [-50, 13],
      [-41, 10],
      [-27, 5],
      [-16, -4],
      [-3, -8],
      [8, -7],
      [19, 0],
      [31, 13],
      [40, 32],
      [52, 45],
      [61, 50],
      [64, 58],
    ],
    [
      [-3, -8],
      [3, -21],
      [7, -36],
      [16, -47],
      [21, -53],
    ],
    [
      [19, 0],
      [35, -3],
      [48, -10],
      [58, -13],
    ],
  ];
  function onPath(x, z) {
    return paths.some((path) =>
      path.slice(1).some(([bx, bz], i) => {
        const [ax, az] = path[i],
          dx = bx - ax,
          dz = bz - az,
          t = clamp(((x - ax) * dx + (z - az) * dz) / (dx * dx + dz * dz), 0, 1);
        return (x - ax - t * dx) ** 2 + (z - az - t * dz) ** 2 < 7;
      }),
    );
  }
  const props = [],
    solids = [],
    caches = [],
    trees = [];
  function solid(x, z, w, d, y, top, kind) {
    solids.push({ x, z, w, d, y, top, kind });
  }
  function cabin(x, z, w, d, style) {
    const y = ground(x, z),
      h = 3.0 + rng() * 1.3;
    props.push({ type: 'cabin', x, z, y, w, d, h, style });
    const wall = (xx, zz, ww, dd, lo, hi) => solid(xx, zz, ww / 2, dd / 2, lo, hi, 'cabin');
    wall(x, z, w, d, y - 3, y + 0.12);
    wall(x, z - d / 2, w, 0.24, y - 0.3, y + h);
    wall(x - w / 2, z, 0.24, d, y - 0.3, y + h);
    wall(x + w / 2, z, 0.24, d, y - 0.3, y + h);
    const wing = (w - 1.85) / 2;
    for (const side of [-1, 1]) wall(x + side * (w / 2 - wing / 2), z + d / 2, wing, 0.24, y - 0.3, y + h);
    wall(x, z + d / 2, 1.85, 0.24, y + 2.48, y + h);
    for (let i = 0; i < 6; i++) {
      const v = (i + 0.5) / 6,
        ww = d / 6;
      wall(
        x,
        z + (v - 0.5) * d,
        w + 0.38,
        ww,
        y + h,
        y + h + Math.max(0.16, 1 - Math.abs(v - 0.5) * 2) * 1.72,
      );
    }
  }
  for (const args of huts) cabin(...args);
  const light = { type: 'light', x: 63, z: 63, y: ground(63, 63) };
  props.push(light);
  solid(63, 63, 2.65, 2.65, light.y - 2, light.y + 23, 'tower');
  function clear(x, z, pad) {
    return solids.every((o) => Math.abs(o.x - x) > o.w + pad || Math.abs(o.z - z) > o.d + pad);
  }
  for (let i = 0; i < 1100 && trees.length < 175; i++) {
    const x = rng() * 248 - 124,
      z = rng() * 248 - 124,
      y = ground(x, z);
    if (y < 2.8 || !clear(x, z, 2.7) || onPath(x, z) || Math.abs(Math.sin(x * 0.04 + z * 0.025)) < 0.19)
      continue;
    const p = {
      type: 'tree',
      x,
      z,
      y,
      h: 4.8 + rng() * 5.7,
      r: 1.4 + rng() * 1.1,
      t: rng(),
      id: trees.length,
    };
    trees.push(p);
    props.push(p);
    solid(x, z, 0.46, 0.46, y - 0.65, y + p.h * 0.72, 'tree');
  }
  for (let i = 0; i < 56; i++) {
    const x = rng() * 249 - 124,
      z = rng() * 249 - 124,
      y = ground(x, z);
    if (y < 0.2 || !clear(x, z, 2) || onPath(x, z)) continue;
    const h = 1 + rng() * 2.3,
      w = 1.25 + rng() * 2.4,
      dw = 1.1 + rng() * 2;
    props.push({ type: 'rock', x, z, y, h, w, d: dw, t: rng() });
    solid(x, z, w * 0.66, dw * 0.66, y - 1, y + h * 0.86, 'rock');
  }
  function cache(x, z, indoors = false) {
    if (
      ground(x, z) < 1 ||
      (!indoors && !clear(x, z, 0.95)) ||
      caches.some((c) => Math.hypot(x - c.x, z - c.z) < 4)
    )
      return;
    caches.push({ x, z, y: ground(x, z) + (indoors ? 0.14 : 0), id: caches.length });
  }
  for (const [x, z] of huts) cache(x - 1, z - 0.8, true);
  for (const p of pois)
    for (let k = 0; k < 5; k++) {
      const a = k * 1.27;
      cache(p.x + Math.sin(a) * 9, p.z + Math.cos(a) * 9);
    }
  for (let k = 0; k < 380 && caches.length < 42; k++) cache(rng() * 208 - 104, rng() * 208 - 104);
  function terrainColor(y, x, z) {
    if (y < -0.4) return [0.39, 0.69, 0.67];
    if (y < 1.35) return [0.89, 0.77, 0.52];
    if (y < 2.35) return [0.69, 0.71, 0.41];
    const m = clamp(
      0.48 + 0.26 * Math.sin(x * 0.084 + phase) * Math.cos(z * 0.094) + 0.2 * Math.sin(z * 0.055 + phase2),
      0,
      1,
    );
    return [0.28 + m * 0.22, 0.48 + m * 0.14, 0.3 + m * 0.045];
  }
  return {
    seed,
    n,
    step,
    edge,
    heights,
    ground,
    rng: random,
    pois,
    paths,
    props,
    solids,
    caches,
    trees,
    terrainColor,
    clear,
  };
}

/* Geometry is shared by the guest's build preview and the authority's collision tests. */
function makeMechanics(world) {
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const sin = Math.sin,
    cos = Math.cos;
  function local(b, x, z) {
    const a = (b.dir * Math.PI) / 2,
      dx = x - b.x,
      dz = z - b.z;
    return [dx * cos(a) - dz * sin(a), dx * sin(a) + dz * cos(a)];
  }
  function buildHeight(b, x, z) {
    const [u, v] = local(b, x, z);
    if (Math.abs(u) > 2.02 || Math.abs(v) > (b.kind === 'wall' ? 0.18 : 2.02)) return -Infinity;
    return (
      b.y + (b.kind === 'wall' ? 3.3 : b.kind === 'floor' ? 0.22 : clamp((v + 2) / 4, 0, 1) * 3.25 + 0.12)
    );
  }
  function preview(p, kind) {
    const dir = ((Math.round(p.yaw / (Math.PI / 2)) % 4) + 4) % 4,
      a = (dir * Math.PI) / 2;
    const x = Math.round((p.x + sin(a) * 4.15) / 4) * 4,
      z = Math.round((p.z + cos(a) * 4.15) / 4) * 4;
    return { kind, x, z, dir, y: Math.round(Math.max(world.ground(x, z), p.y - 0.2) * 10) / 10 };
  }
  function support(x, z, feet, builds) {
    let h = Math.max(-0.38, world.ground(x, z));
    for (const b of builds) {
      if (Math.abs(x - b.x) > 2.9 || Math.abs(z - b.z) > 2.9) continue;
      const top = buildHeight(b, x, z);
      if (top <= feet + 0.65 && top > h) h = top;
    }
    for (const o of world.solids) {
      if (o.top > feet + 0.48 || Math.abs(x - o.x) > o.w + 0.1 || Math.abs(z - o.z) > o.d + 0.1) continue;
      h = Math.max(h, o.top);
    }
    return h;
  }
  function blocked(x, z, feet, builds) {
    for (const o of world.solids)
      if (
        Math.abs(x - o.x) < o.w + 0.31 &&
        Math.abs(z - o.z) < o.d + 0.31 &&
        feet < o.top - 0.38 &&
        feet + 1.65 > o.y
      )
        return true;
    for (const b of builds) {
      if (Math.abs(x - b.x) > 3 || Math.abs(z - b.z) > 3 || feet + 1.65 < b.y) continue;
      const [u, v] = local(b, x, z);
      if (b.kind === 'wall' && Math.abs(u) < 2.27 && Math.abs(v) < 0.43 && feet < b.y + 2.95) return true;
      if (
        b.kind === 'ramp' &&
        Math.abs(u) < 2.12 &&
        Math.abs(v) < 2.12 &&
        buildHeight(b, x, z) > feet + 0.7
      )
        return true;
    }
    return false;
  }
  function move(p, inp, dt, builds) {
    const mag = Math.hypot(inp.mx, inp.mz),
      norm = Math.max(1, mag);
    const wading = p.y < 0.05 && world.ground(p.x, p.z) < -0.8;
    const speed = p.glide ? 10 : wading ? 3.5 : inp.sprint ? 8.55 : 5.85;
    const dx = ((inp.mx * cos(p.yaw) + inp.mz * sin(p.yaw)) / norm) * speed * dt;
    const dz = ((inp.mz * cos(p.yaw) - inp.mx * sin(p.yaw)) / norm) * speed * dt;
    const nextX = clamp(p.x + dx, -151, 151),
      nextZ = clamp(p.z + dz, -151, 151);
    if (!blocked(nextX, p.z, p.y, builds)) p.x = nextX;
    if (!blocked(p.x, nextZ, p.y, builds)) p.z = nextZ;
    const base = support(p.x, p.z, p.y, builds);
    p.vy = p.glide ? -5.5 : Math.max(-27, p.vy - 23 * dt);
    let nextY = p.y + p.vy * dt;
    if (p.vy > 0) {
      const head = p.y + 1.94;
      let ceiling = Infinity;
      for (const o of world.solids)
        if (o.y >= head - 0.025 && Math.abs(o.x - p.x) < o.w + 0.23 && Math.abs(o.z - p.z) < o.d + 0.23)
          ceiling = Math.min(ceiling, o.y);
      for (const b of builds)
        if (b.y >= head - 0.025 && buildHeight(b, p.x, p.z) > -Infinity) ceiling = Math.min(ceiling, b.y);
      if (nextY + 1.94 > ceiling) {
        nextY = ceiling - 1.94;
        p.vy = 0;
      }
    }
    p.y = nextY;
    p.onGround = p.y <= base + 0.025;
    if (p.onGround) {
      p.y = base;
      p.vy = 0;
      p.glide = false;
    }
    p.move = mag > 0.15 ? speed : 0;
  }
  function boxRay(o, d, mn, mx, limit) {
    let lo = 0,
      hi = limit;
    for (let i = 0; i < 3; i++) {
      if (Math.abs(d[i]) < 0.000001) {
        if (o[i] < mn[i] || o[i] > mx[i]) return Infinity;
        continue;
      }
      let a = (mn[i] - o[i]) / d[i],
        b = (mx[i] - o[i]) / d[i];
      if (a > b) [a, b] = [b, a];
      lo = Math.max(lo, a);
      hi = Math.min(hi, b);
      if (lo > hi) return Infinity;
    }
    return lo;
  }
  function trace(o, d, limit, builds, actors = [], skip = -1) {
    let t = limit,
      actor = -1,
      build = null,
      head = false;
    function accept(v, i = -1, b = null, h = false) {
      if (v < t) {
        t = v;
        actor = i;
        build = b;
        head = h;
      }
    }
    for (const s of world.solids) {
      const v = boxRay(o, d, [s.x - s.w, s.y, s.z - s.d], [s.x + s.w, s.top, s.z + s.d], t);
      accept(v);
    }
    for (const b of builds) {
      const a = (b.dir * Math.PI) / 2,
        c = cos(a),
        s = sin(a),
        [u, v] = local(b, o[0], o[2]);
      const ro = [u, o[1] - b.y, v],
        rd = [d[0] * c - d[2] * s, d[1], d[0] * s + d[2] * c];
      const w = b.kind === 'wall' ? 0.16 : 2,
        height = b.kind === 'floor' ? 0.22 : 3.35;
      let hit = boxRay(ro, rd, [-2, 0, -w], [2, height, w], t);
      if (hit !== Infinity && b.kind === 'ramp') {
        const above = ro[1] + rd[1] * hit - ((ro[2] + rd[2] * hit + 2) * 0.8125 + 0.12);
        if (above > 0) {
          const slope = rd[1] - rd[2] * 0.8125;
          if (slope >= -0.00001) continue;
          hit -= above / slope;
          if (hit > t || Math.abs(ro[0] + rd[0] * hit) > 2 || Math.abs(ro[2] + rd[2] * hit) > 2) continue;
        }
      }
      accept(hit, -1, b);
    }
    for (const p of actors)
      if (p.idx !== skip && p.hp > 0) {
        const hit = boxRay(o, d, [p.x - 0.4, p.y + 0.08, p.z - 0.4], [p.x + 0.4, p.y + 2.03, p.z + 0.4], t);
        accept(hit, p.idx, null, o[1] + d[1] * hit > p.y + 1.55);
      }
    const stride = limit < 12 ? 0.28 : 1.35;
    for (let s = stride; s < t; s += stride)
      if (o[1] + d[1] * s < Math.max(-0.55, world.ground(o[0] + d[0] * s, o[2] + d[2] * s))) {
        accept(s);
        break;
      }
    return { t, actor, build, head, end: [o[0] + d[0] * t, o[1] + d[1] * t, o[2] + d[2] * t] };
  }
  function camera(p, yaw, pitch, builds, zoom = false) {
    const f = [sin(yaw) * cos(pitch), sin(pitch), cos(yaw) * cos(pitch)],
      r = [cos(yaw), 0, -sin(yaw)];
    const pivot = [p.x, p.y + 1.63, p.z],
      back = p.glide ? 7.6 : zoom ? 2.5 : 4.8,
      side = zoom ? 0.54 : 0.81;
    const offset = [-f[0] * back + r[0] * side, -f[1] * back + 0.66, -f[2] * back + r[2] * side];
    const len = Math.hypot(...offset),
      d = offset.map((v) => v / len);
    const dist = Math.max(0.08, trace(pivot, d, len, builds).t - 0.18);
    return { pos: pivot.map((v, i) => v + d[i] * dist), yaw, pitch, f };
  }
  return { clamp, preview, support, blocked, move, trace, camera };
}

function makeSimulation(world, humans) {
  const geo = makeMechanics(world),
    { clamp } = geo,
    rand = world.rng(world.seed ^ 0x71381);
  const botNames = [
    'Kestrel',
    'Rivet',
    'Caldera',
    'Piper',
    'Sundog',
    'Bracken',
    'Mica',
    'Switch',
    'Bramble',
    'Cobalt',
    'Roan',
    'Tiller',
  ];
  const roster = humans.map((p) => ({ id: p.id, name: p.name, bot: false }));
  for (let i = roster.length; i < 12; i++)
    roster.push({ id: 'bot-' + i, name: botNames[(i + (world.seed % 12)) % 12], bot: true });
  const actors = [],
    builds = [],
    opened = new Set(),
    events = [];
  let elapsed = 0,
    tick = 0,
    buildingId = 0,
    winner = -1,
    done = false,
    stormClock = 0;
  const angle = rand() * 6.28,
    slots = Array.from({ length: 12 }, (_, i) => i);
  for (let i = slots.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [slots[i], slots[j]] = [slots[j], slots[i]];
  }
  function neutral() {
    return { mx: 0, mz: 0, sprint: false, fire: false, zoom: false };
  }
  for (let i = 0; i < roster.length; i++) {
    let a = angle + (slots[i] * Math.PI) / 6,
      r = 54 + rand() * 28,
      x = Math.sin(a) * r,
      z = Math.cos(a) * r;
    for (let k = 0; k < 18 && !world.clear(x, z, 1); k++) {
      a += 0.09;
      x = Math.sin(a) * r;
      z = Math.cos(a) * r;
    }
    actors.push({
      idx: i,
      x,
      z,
      y: world.ground(x, z) + 23 + rand() * 4,
      yaw: Math.atan2(-x, -z),
      pitch: -0.13,
      vy: 0,
      glide: true,
      onGround: false,
      hp: 100,
      shield: 25,
      kills: 0,
      rank: 0,
      slot: 1,
      mag: 24,
      reserve: 72,
      shells: 5,
      spare: 20,
      rifleTier: 0,
      shotTier: 0,
      wood: 60,
      pots: 1,
      cool: 0,
      reload: 0,
      drink: 0,
      move: 0,
      inp: neutral(),
      lastInput: 0,
      seq: -1,
      aiAt: 0,
      target: -1,
      aiFire: 0,
      aiCover: 0,
      roam: rand() * 6.28,
      treeAt: 0,
      buildAt: 0,
    });
  }
  const stages = [];
  let cx = 0,
    cz = 0,
    radius = 136,
    start = 0;
  for (const [hold, travel, r] of [
    [38, 32, 88],
    [23, 30, 50],
    [16, 24, 27],
    [12, 18, 11],
    [7, 16, 0],
  ]) {
    const a = rand() * 6.28,
      shift = (radius - r) * (0.28 + rand() * 0.38),
      nx = cx + Math.cos(a) * shift,
      nz = cz + Math.sin(a) * shift;
    stages.push({ x: cx, z: cz, r: radius, nx, nz, nr: r, start, hold, travel });
    start += hold + travel;
    cx = nx;
    cz = nz;
    radius = r;
  }
  function storm() {
    const i = stages.findIndex((s) => elapsed < s.start + s.hold + s.travel);
    const s = stages[i < 0 ? stages.length - 1 : i],
      t = clamp((elapsed - s.start - s.hold) / s.travel, 0, 1);
    const moving = elapsed >= s.start + s.hold;
    return {
      x: s.x + (s.nx - s.x) * t,
      z: s.z + (s.nz - s.z) * t,
      r: s.r + (s.nr - s.r) * t,
      nx: s.nx,
      nz: s.nz,
      nr: s.nr,
      phase: i < 0 ? 6 : i + 1,
      moving,
      left: Math.max(0, Math.ceil(s.start + s.hold + (moving ? s.travel : 0) - elapsed)),
    };
  }
  function event(type, data = {}) {
    events.push({ type, ...data });
    if (events.length > 400) events.shift();
  }
  const alive = () => actors.filter((p) => p.hp > 0);
  function pop(p, text) {
    event('note', { who: p.idx, text });
  }
  function eliminate(p, by, why) {
    if (p.rank) return;
    p.hp = 0;
    p.shield = 0;
    p.rank = alive().length + 1;
    p.inp = neutral();
    if (by && by !== p) {
      by.kills++;
      by.wood = Math.min(200, by.wood + 15);
      by.reserve = Math.min(180, by.reserve + 12);
    }
    event('elim', { who: p.idx, by: by ? by.idx : -1, why, rank: p.rank });
  }
  function damage(p, amount, by, why) {
    const s = why === 'storm' ? 0 : Math.min(p.shield, amount);
    p.shield -= s;
    p.hp = Math.max(0, p.hp - (amount - s));
    p.drink = 0;
    if (!p.hp) eliminate(p, by, why);
  }
  function reload(p) {
    if (p.reload || p.drink || p.slot > 2) return;
    if (p.slot === 1 && p.mag < 24 && p.reserve > 0) p.reload = 1.65;
    if (p.slot === 2 && p.shells < 5 && p.spare > 0) p.reload = 2.05;
  }
  function shoot(p) {
    if (done || !p.hp || p.glide || p.cool > 0 || p.reload > 0 || p.drink > 0 || p.slot > 2) return;
    const shotgun = p.slot === 2,
      ammo = shotgun ? 'shells' : 'mag';
    if (!p[ammo]) {
      reload(p);
      return;
    }
    p[ammo]--;
    p.cool = shotgun ? 0.78 : 0.145;
    const cam = geo.camera(p, p.yaw, p.pitch, builds, p.inp.zoom);
    const origin = [p.x + Math.sin(p.yaw) * 0.35, p.y + 1.45, p.z + Math.cos(p.yaw) * 0.35];
    const aim = geo.trace(cam.pos, cam.f, 143, builds, actors, p.idx).end;
    const dx = aim[0] - origin[0],
      dy = aim[1] - origin[1],
      dz = aim[2] - origin[2];
    const yaw = Math.atan2(dx, dz),
      pitch = Math.atan2(dy, Math.hypot(dx, dz)),
      traces = [];
    let totalDamage = 0;
    for (let n = 0; n < (shotgun ? 7 : 1); n++) {
      const spread = shotgun ? 0.058 : p.inp.zoom ? 0.0016 : 0.004;
      const a = yaw + (rand() - 0.5) * 2 * spread,
        b = pitch + (rand() - 0.5) * 2 * spread;
      const dir = [Math.sin(a) * Math.cos(b), Math.sin(b), Math.cos(a) * Math.cos(b)];
      const hit = geo.trace(origin, dir, shotgun ? 56 : 143, builds, actors, p.idx);
      if (n < 3) traces.push(hit.end);
      if (hit.actor >= 0) {
        const tier = shotgun ? p.shotTier : p.rifleTier;
        const amount = Math.round(
          (shotgun ? 12 : 23) *
            (1 + tier * 0.14) *
            (hit.head ? 1.48 : 1) *
            (roster[p.idx].bot ? 0.64 : 1) *
            (shotgun ? clamp(1.15 - hit.t / 75, 0.38, 1) : 1),
        );
        damage(actors[hit.actor], amount, p, shotgun ? 'Breaker' : 'Carbine');
        totalDamage += amount;
      } else if (hit.build) {
        hit.build.hp -= shotgun ? 10 : 22;
        if (hit.build.hp <= 0) builds.splice(builds.indexOf(hit.build), 1);
      }
    }
    event('shot', { who: p.idx, weapon: p.slot, origin, ends: traces, damage: totalDamage });
  }
  function openCache(p) {
    const c = world.caches.find(
      (c) => !opened.has(c.id) && Math.hypot(c.x - p.x, c.z - p.z) < 3.25 && Math.abs(c.y - p.y) < 3.2,
    );
    if (!c) {
      pop(p, 'Move closer to a glowing supply crate');
      return;
    }
    opened.add(c.id);
    p.wood = Math.min(200, p.wood + 30);
    p.reserve += 24;
    p.spare += 5;
    p.pots = Math.min(4, p.pots + 1);
    p.hp = Math.min(100, p.hp + 15);
    const gun = (c.id + world.seed) % 2 ? 'rifleTier' : 'shotTier';
    const up = p[gun] < 2;
    p[gun] = Math.min(2, p[gun] + 1);
    const upgrade = up
      ? ['', 'Tuned', 'Elite'][p[gun]] + ' ' + (gun === 'rifleTier' ? 'carbine' : 'shotgun') + '  /  '
      : '';
    event('loot', { who: p.idx, text: upgrade + '+30 timber  /  ammo  /  tonic' });
  }
  function harvest(p) {
    if (elapsed < p.treeAt) return;
    const tree = world.trees.find(
      (t) => Math.hypot(t.x - p.x, t.z - p.z) < 3.25 && Math.abs(t.y - p.y) < 3,
    );
    if (!tree) {
      pop(p, 'Move next to a tree to harvest timber');
      return;
    }
    p.treeAt = elapsed + 0.85;
    p.wood = Math.min(200, p.wood + 15);
    event('harvest', { who: p.idx, text: '+15 timber' });
  }
  function build(p, kind) {
    if (p.glide || elapsed < p.buildAt) return;
    if (p.wood < 10) {
      pop(p, 'Need 10 timber');
      return;
    }
    const b = geo.preview(p, kind);
    const a = (b.dir * Math.PI) / 2,
      depth = kind === 'wall' ? 0.1 : 1.7;
    const obstructed = [
      [0, 0],
      [-1.7, -depth],
      [1.7, -depth],
      [-1.7, depth],
      [1.7, depth],
    ].some(([u, v]) =>
      geo.blocked(
        b.x + u * Math.cos(a) + v * Math.sin(a),
        b.z - u * Math.sin(a) + v * Math.cos(a),
        b.y + 0.45,
        [],
      ),
    );
    if (
      Math.abs(b.x) > 149 ||
      Math.abs(b.z) > 149 ||
      obstructed ||
      builds.some(
        (o) =>
          o.kind === kind &&
          o.x === b.x &&
          o.z === b.z &&
          Math.abs(o.y - b.y) < 1 &&
          (kind === 'floor' || o.dir === b.dir || (kind === 'wall' && o.dir % 2 === b.dir % 2)),
      ) ||
      actors.some((q) => q.hp > 0 && Math.hypot(q.x - b.x, q.z - b.z) < 1.35 && Math.abs(q.y - b.y) < 2)
    ) {
      pop(p, 'Placement blocked');
      return;
    }
    if (builds.length >= 96) {
      pop(p, 'Island build limit reached');
      return;
    }
    p.wood -= 10;
    p.buildAt = elapsed + 0.28;
    builds.push({ ...b, id: ++buildingId, hp: kind === 'wall' ? 145 : 110 });
    event('build', { who: p.idx });
  }
  function equip(p, slot) {
    if ([1, 2, 3].includes(slot) && slot !== p.slot) {
      p.slot = slot;
      p.reload = 0;
      p.drink = 0;
    }
  }
  function action(idx, a, data = {}) {
    const p = actors[idx];
    if (!p || !p.hp || done) return;
    if (Number.isFinite(data.yaw)) p.yaw = Math.atan2(Math.sin(data.yaw), Math.cos(data.yaw));
    if (Number.isFinite(data.pitch)) p.pitch = clamp(data.pitch, -1.22, 0.89);
    if (a === 'equip') {
      equip(p, data.slot);
      return;
    }
    if (a === 'jump') {
      if (p.onGround && !p.glide) {
        p.vy = 8.1;
        p.onGround = false;
      }
      return;
    }
    if (p.glide) return;
    if (a === 'fire') {
      shoot(p);
      return;
    }
    if (a === 'reload') {
      reload(p);
      return;
    }
    if (a === 'open') {
      openCache(p);
      return;
    }
    if (a === 'harvest') {
      harvest(p);
      return;
    }
    if (a === 'shield') {
      if (p.drink || p.reload) return;
      if (!p.pots || p.shield >= 100) {
        pop(p, p.pots ? 'Shield is full' : 'No shield tonics');
        return;
      }
      p.drink = 1.8;
      return;
    }
    if (['wall', 'ramp', 'floor'].includes(a)) build(p, a);
  }
  function input(idx, d) {
    const p = actors[idx];
    if (!p || !p.hp || done || !d || !Number.isSafeInteger(d.seq) || d.seq <= p.seq) return;
    p.seq = d.seq;
    p.lastInput = elapsed;
    const safe = (v) => (Number.isFinite(v) ? clamp(v, -1, 1) : 0);
    p.inp = {
      mx: safe(d.mx),
      mz: safe(d.mz),
      sprint: d.sprint === true,
      fire: d.fire === true,
      zoom: d.zoom === true,
    };
    if (Number.isFinite(d.yaw)) p.yaw = Math.atan2(Math.sin(d.yaw), Math.cos(d.yaw));
    if (Number.isFinite(d.pitch)) p.pitch = clamp(d.pitch, -1.22, 0.89);
  }
  function bot(p, s, dt) {
    if (elapsed >= p.aiAt) {
      p.aiAt = elapsed + 0.27 + rand() * 0.4;
      let best = 58,
        target = -1;
      for (const q of actors)
        if (q !== p && q.hp > 0 && !q.glide) {
          const dist = Math.hypot(q.x - p.x, q.z - p.z);
          if (dist > best) continue;
          const o = [p.x, p.y + 1.54, p.z],
            d = [q.x - p.x, q.y + 1.05 - o[1], q.z - p.z],
            len = Math.hypot(...d);
          if (
            geo.trace(
              o,
              d.map((v) => v / len),
              len,
              builds,
            ).t <
            len - 1
          )
            continue;
          best = dist;
          target = q.idx;
        }
      p.target = target;
      p.roam += (rand() - 0.5) * 1.25;
      if (rand() < 0.22 && p.onGround && p.move) p.vy = 7.3;
      if (!p.glide && p.onGround && elapsed > 8) {
        if (
          world.caches.some(
            (c) => !opened.has(c.id) && Math.hypot(c.x - p.x, c.z - p.z) < 2.6 && Math.abs(c.y - p.y) < 2.4,
          )
        )
          openCache(p);
        if (target >= 0 && p.shield < 18 && elapsed >= p.aiCover && p.wood >= 10 && rand() < 0.22) {
          build(p, 'wall');
          p.aiCover = elapsed + 15 + rand() * 9;
        }
      }
    }
    const outside = Math.hypot(p.x - s.x, p.z - s.z) > Math.max(3, s.r - 5);
    const q = actors[p.target],
      combat = q && q.hp > 0 && !p.glide && !outside;
    let dx, dz;
    if (combat) {
      dx = q.x - p.x;
      dz = q.z - p.z;
    } else if (outside || Math.hypot(p.x - s.nx, p.z - s.nz) > s.nr + 4) {
      dx = s.nx - p.x;
      dz = s.nz - p.z;
    } else {
      dx = Math.sin(p.roam);
      dz = Math.cos(p.roam);
    }
    let want = Math.atan2(dx, dz);
    if (!combat && geo.blocked(p.x + Math.sin(want) * 2, p.z + Math.cos(want) * 2, p.y, builds))
      want += 1.32;
    const diff = Math.atan2(Math.sin(want - p.yaw), Math.cos(want - p.yaw));
    p.yaw += diff * Math.min(1, dt * (combat ? 8 : 5));
    p.inp.sprint = outside;
    p.inp.mz = combat ? (Math.hypot(dx, dz) > 18 ? 0.72 : 0.04) : 0.88;
    p.inp.mx = combat ? Math.sin(elapsed * 1.12 + p.idx) * 0.83 : 0;
    p.pitch = combat
      ? Math.atan2(q.y + 1.04 - (p.y + 1.65), Math.max(2, Math.hypot(dx, dz))) +
        Math.sin(elapsed * 4 + p.idx) * 0.018
      : -0.12;
    if (combat && elapsed > 9 && Math.abs(diff) < 0.22 && elapsed > p.aiFire) {
      shoot(p);
      p.aiFire = elapsed + 0.53 + rand() * 0.76;
    }
    if (!p.mag && !p.reload) {
      if (p.reserve < 1) p.reserve = 24;
      reload(p);
    }
  }
  function update(dt) {
    if (done) return;
    elapsed += dt;
    tick++;
    const s = storm();
    stormClock += dt;
    const stormHit = stormClock >= 1;
    if (stormHit) stormClock -= 1;
    for (const p of actors)
      if (p.hp > 0) {
        p.cool = Math.max(0, p.cool - dt);
        if (p.reload > 0 && (p.reload = Math.max(0, p.reload - dt)) === 0) {
          const n = p.slot === 1 ? Math.min(24 - p.mag, p.reserve) : Math.min(5 - p.shells, p.spare);
          if (p.slot === 1) {
            p.mag += n;
            p.reserve -= n;
          } else {
            p.shells += n;
            p.spare -= n;
          }
        }
        if (p.drink > 0 && (p.drink = Math.max(0, p.drink - dt)) === 0) {
          p.pots--;
          p.shield = Math.min(100, p.shield + 45);
          event('tonic', { who: p.idx, text: '+45 shield' });
        }
        if (roster[p.idx].bot) bot(p, s, dt);
        else if (elapsed - p.lastInput > 0.55) p.inp = neutral();
        geo.move(p, p.inp, dt, builds);
        if (p.inp.fire) shoot(p);
        if (stormHit && (s.phase === 6 || Math.hypot(p.x - s.x, p.z - s.z) > s.r))
          damage(p, [0, 2, 3, 5, 7, 11, 20][s.phase], null, 'storm');
      }
    const left = alive();
    if (left.length <= 1) {
      winner = left[0]?.idx ?? -1;
      if (left[0]) left[0].rank = 1;
      done = true;
      event('finish', { winner });
    }
  }
  const rounded = (v) => Math.round(v * 100) / 100;
  function snapshot() {
    const players = actors.map((p) => ({
      x: rounded(p.x),
      y: rounded(p.y),
      z: rounded(p.z),
      yaw: rounded(p.yaw),
      pitch: rounded(p.pitch),
      hp: p.hp,
      shield: p.shield,
      kills: p.kills,
      rank: p.rank,
      slot: p.slot,
      mag: p.mag,
      reserve: p.reserve,
      shells: p.shells,
      spare: p.spare,
      rifleTier: p.rifleTier,
      shotTier: p.shotTier,
      wood: p.wood,
      pots: p.pots,
      reload: rounded(p.reload),
      drink: rounded(p.drink),
      glide: p.glide,
      move: rounded(p.move),
    }));
    return {
      tick,
      time: rounded(elapsed),
      players,
      builds: builds.map((b) => ({ ...b })),
      opened: [...opened],
      storm: storm(),
      winner,
      done,
    };
  }
  function disconnect(idx) {
    const p = actors[idx];
    if (p && p.hp > 0 && !done) eliminate(p, null, 'disconnect');
  }
  return {
    roster,
    actors,
    builds,
    geo,
    events,
    input,
    action,
    update,
    snapshot,
    disconnect,
    get done() {
      return done;
    },
  };
}

/* Tiny flat-shaded WebGL renderer. Static island geometry is uploaded once per seed. */
function makeRenderer(canvas) {
  const gl = canvas.getContext('webgl', {
    alpha: false,
    antialias: true,
    powerPreference: 'high-performance',
  });
  if (!gl)
    throw new Error('WebGL is unavailable. Enable hardware acceleration or use a WebGL-capable browser.');
  const PI = Math.PI,
    TAU = PI * 2,
    sin = Math.sin,
    cos = Math.cos;
  function program(vs, fs, attrs, uniforms) {
    function shader(type, src) {
      const s = gl.createShader(type);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(s));
      return s;
    }
    const p = gl.createProgram();
    gl.attachShader(p, shader(gl.VERTEX_SHADER, vs));
    gl.attachShader(p, shader(gl.FRAGMENT_SHADER, fs));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw Error(gl.getProgramInfoLog(p));
    const out = { p };
    for (const k of attrs) out[k] = gl.getAttribLocation(p, k);
    for (const k of uniforms) out[k] = gl.getUniformLocation(p, k);
    return out;
  }
  const sky = program(
    'attribute vec2 a; varying vec2 uv; void main(){uv=a;gl_Position=vec4(a,0.,1.);}',
    `precision highp float; varying vec2 uv; uniform vec3 right,up,forward,eye; uniform vec2 lens; uniform float clock;
    float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
    float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.),f.x),f.y);}
    void main(){vec3 d=normalize(forward+up*uv.y*lens.y+right*uv.x*lens.x);
      vec3 sky=mix(vec3(.80,.88,.84),vec3(.29,.66,.76),smoothstep(-.04,.59,d.y));
      vec3 sun=normalize(vec3(-.52,.43,.67)); float k=max(dot(d,sun),0.);
      sky+=vec3(.22,.18,.09)*pow(k,14.)+vec3(.8,.59,.29)*smoothstep(.997,.998,k);
      if(d.y>.012){vec2 q=d.xz*1.9/max(d.y,.03)+vec2(clock*.005,0.)+eye.xz*.0015;
        float n=noise(q*.52)*.58+noise(q*1.08)*.28+noise(q*2.04)*.14;
        float c=smoothstep(.53,.67,n)*smoothstep(.018,.15,d.y);
        sky=mix(sky,vec3(.97,.96,.86),c*.88);}
      gl_FragColor=vec4(sky,1.);}`,
    ['a'],
    ['right', 'up', 'forward', 'eye', 'lens', 'clock'],
  );
  const scene = program(
    `attribute vec3 pos,norm,col; attribute float mat; uniform vec3 right,up,forward,eye;uniform vec2 lens;
     varying vec3 vCol,vPos,vNorm;varying float vMat,vDepth;
     void main(){vec3 p=pos-eye;float z=dot(p,forward);gl_Position=vec4(dot(p,right)/lens.x,dot(p,up)/lens.y,1.00023*z-.16,z);
     vDepth=z;vCol=col;vPos=pos;vNorm=norm;vMat=mat;}`,
    `precision highp float; varying vec3 vCol,vPos,vNorm;varying float vMat,vDepth;uniform float clock,alpha;
    void main(){vec3 c=vCol;float lighting=.79+.28*max(dot(normalize(vNorm),normalize(vec3(-.52,.88,.34))),0.)-.055*max(-vNorm.y,0.);
      c*=lighting;
      if(vMat>.5 && vMat<1.5){float w=sin(vPos.z*.76+sin(vPos.x*.11+clock*.22)*1.65+clock*.9);
        float k=sin(vPos.x*.21+vPos.z*.18+clock*.32);c=mix(vec3(.14,.58,.62),vec3(.23,.72,.71),.5+.5*sin(vPos.z*.055+vPos.x*.039));
        c+=vec3(.27,.24,.16)*smoothstep(.955,.994,w)*smoothstep(.32,.8,k);}
      if(vMat>1.5 && vMat<2.5)c=vCol;
      if(vMat>2.5){float mottle=.5+.5*sin(vPos.x*.52+sin(vPos.z*.36))*cos(vPos.z*.48);
        vec3 sand=mix(vec3(.72,.68,.49),vec3(.91,.80,.57),smoothstep(-.25,1.6,vPos.y));
        c=mix(sand*lighting,c,smoothstep(1.15,3.1,vPos.y+mottle*.37))*(.977+.042*mottle);}
      float haze=smoothstep(65.,480.,max(vDepth,0.))*.77;c=mix(c,vec3(.69,.81,.79),haze);
      gl_FragColor=vec4(c,alpha);}`,
    ['pos', 'norm', 'col', 'mat'],
    ['right', 'up', 'forward', 'eye', 'lens', 'clock', 'alpha'],
  );
  const quad = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quad);
  gl.bufferData(
    gl.ARRAY_BUFFER,
    new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]),
    gl.STATIC_DRAW,
  );
  const staticBuffer = gl.createBuffer(),
    dynamicBuffer = gl.createBuffer(),
    veilBuffer = gl.createBuffer();
  let world,
    staticCount = 0,
    verts = [],
    material = 0;
  const colors = new Map();
  function rgb(c) {
    if (Array.isArray(c)) return c;
    if (!colors.has(c)) {
      const n = parseInt(c, 16);
      colors.set(c, [(n >> 16) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]);
    }
    return colors.get(c);
  }
  const scale = (c, k) => rgb(c).map((v) => v * k);
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const unit = (a) => {
    const m = Math.hypot(...a) || 1;
    return a.map((v) => v / m);
  };
  function tri(a, b, c, color, hint) {
    let n = unit(cross(sub(b, a), sub(c, a)));
    if (hint && n[0] * hint[0] + n[1] * hint[1] + n[2] * hint[2] < 0) n = n.map((v) => -v);
    const v = rgb(color);
    for (const p of [a, b, c]) verts.push(p[0], p[1], p[2], n[0], n[1], n[2], v[0], v[1], v[2], material);
  }
  function face(a, b, c, d, color, hint) {
    tri(a, b, c, color, hint);
    tri(a, c, d, color, hint);
  }
  function box(x, y, z, w, h, d, col, yaw = 0) {
    const c = cos(yaw),
      s = sin(yaw),
      p = (u, v, k) => [x + u * c + k * s, y + v, z - u * s + k * c];
    const a = p(-w / 2, 0, -d / 2),
      b = p(w / 2, 0, -d / 2),
      e = p(w / 2, 0, d / 2),
      f = p(-w / 2, 0, d / 2);
    const top = (q) => [q[0], q[1] + h, q[2]],
      A = top(a),
      B = top(b),
      E = top(e),
      F = top(f);
    face(a, A, B, b, col, [-s, 0, -c]);
    face(e, E, F, f, col, [s, 0, c]);
    face(b, B, E, e, col, [c, 0, -s]);
    face(f, F, A, a, col, [-c, 0, s]);
    face(A, F, E, B, col, [0, 1, 0]);
    face(a, b, e, f, col, [0, -1, 0]);
  }
  function tapered(x, y, z, r1, r2, h, col, sides = 7, rotation = 0, stretch = 1) {
    const lower = [],
      upper = [];
    for (let i = 0; i < sides; i++) {
      const a = (i * TAU) / sides + rotation;
      lower.push([x + sin(a) * r1, y, z + cos(a) * r1 * stretch]);
      upper.push([x + sin(a) * r2, y + h, z + cos(a) * r2 * stretch]);
    }
    for (let i = 0; i < sides; i++) {
      const j = (i + 1) % sides,
        mid = ((i + 0.5) * TAU) / sides + rotation;
      if (r2 > 0.0001) face(lower[i], lower[j], upper[j], upper[i], col, [sin(mid), 0.2, cos(mid)]);
      else tri(lower[i], lower[j], upper[i], col, [sin(mid), 0.2, cos(mid)]);
      if (r2 > 0.0001) tri([x, y + h, z], upper[i], upper[j], col, [0, 1, 0]);
    }
  }
  function beam(a, b, r, color, sides = 5) {
    const dir = unit(sub(b, a)),
      u = unit(cross(dir, Math.abs(dir[1]) > 0.9 ? [1, 0, 0] : [0, 1, 0])),
      v = cross(dir, u),
      start = [],
      end = [];
    for (let i = 0; i < sides; i++) {
      const th = (i * TAU) / sides,
        off = u.map((n, j) => r * (n * cos(th) + v[j] * sin(th)));
      start.push(a.map((n, j) => n + off[j]));
      end.push(b.map((n, j) => n + off[j]));
    }
    for (let i = 0; i < sides; i++) {
      const j = (i + 1) % sides;
      face(start[i], start[j], end[j], end[i], color, sub(start[i], a));
    }
  }
  function shadow(x, z, rx, rz, color, groundFn) {
    const y = groundFn(x, z) + 0.045;
    for (let i = 0; i < 8; i++) {
      const a = (i * PI) / 4,
        b = a + PI / 4,
        ax = x + cos(a) * rx,
        az = z + sin(a) * rz,
        bx = x + cos(b) * rx,
        bz = z + sin(b) * rz;
      tri(
        [x, y, z],
        [ax, groundFn(ax, az) + 0.045, az],
        [bx, groundFn(bx, bz) + 0.045, bz],
        color,
        [0, 1, 0],
      );
    }
  }
  function drawCabin(o) {
    const { x, y, z, w, d, h } = o,
      y1 = y + h,
      roof = ['af5031', '3e787b', '526271'][o.style],
      paint = ['e0ce9d', 'ccad78', 'c5cbb2'][o.style];
    box(x, y - 2.6, z, w, 2.72, d, '9b845e');
    box(x, y + 0.12, z - d / 2, w, h - 0.12, 0.24, paint);
    for (const side of [-1, 1]) box(x + (side * w) / 2, y + 0.12, z, 0.24, h - 0.12, d, paint);
    const wing = (w - 1.85) / 2;
    for (const side of [-1, 1])
      box(x + side * (w / 2 - wing / 2), y + 0.12, z + d / 2, wing, h - 0.12, 0.24, paint);
    box(x, y + 2.48, z + d / 2, 1.85, h - 2.48, 0.24, paint);
    for (const side of [-1, 1]) {
      box(x, y1 - 0.34, z + (side * d) / 2, w + 0.15, 0.29, 0.29, '665843');
      box(x + (side * w) / 2, y1 - 0.34, z, 0.29, 0.29, d + 0.15, '665843');
    }
    const e = w / 2 + 0.55,
      k = d / 2 + 0.57,
      peak = y1 + 1.72;
    face([x - e, y1, z - k], [x + e, y1, z - k], [x + e, peak, z], [x - e, peak, z], roof, [0, 1, -1]);
    face([x - e, peak, z], [x + e, peak, z], [x + e, y1, z + k], [x - e, y1, z + k], roof, [0, 1, 1]);
    for (const sign of [-1, 1])
      tri(
        [x + (sign * w) / 2, y1, z - d / 2],
        [x + (sign * w) / 2, peak, z],
        [x + (sign * w) / 2, y1, z + d / 2],
        paint,
        [sign, 0, 0],
      );
    for (let i = 0; i < 2; i++) {
      const xx = x - w * 0.23 + i * w * 0.46;
      box(xx, y + 0.9, z - d / 2 - 0.045, 1.25, 1.22, 0.13, 'f2dfad');
      box(xx, y + 1.03, z - d / 2 - 0.13, 1.03, 0.97, 0.08, '36747c');
      box(xx, y + 1.03, z - d / 2 - 0.19, 0.08, 0.98, 0.07, 'e6cea0');
    }
    for (const side of [-1, 1]) {
      box(x + side * 0.99, y + 0.12, z + d / 2, 0.14, 2.4, 0.4, '6c624e');
      box(x + side * w * 0.29, y + 1.08, z + d / 2 + 0.14, 1.0, 1.04, 0.1, 'f6dfa9');
      box(x + side * w * 0.29, y + 1.18, z + d / 2 + 0.21, 0.82, 0.85, 0.08, '498486');
    }
    box(x, y + 2.42, z + d / 2, 2.16, 0.17, 0.42, '655d4b');
    box(x - 0.97, y + 0.15, z + d / 2 - 0.83, 0.13, 2.25, 1.64, '48726a');
    box(x, y + 0.125, z + d * 0.2, 1.65, 0.025, 1.05, 'a25c42');
    box(x, y - 0.03, z + d / 2 + 0.47, 2.03, 0.16, 0.9, 'ad9575');
    box(x - w * 0.27, y1 + 0.2, z + 0.5, 0.55, 1.85, 0.56, 'b57853');
  }
  function lighthouse(o) {
    const { x, y, z } = o;
    tapered(x, y - 2, z, 3.55, 3.05, 3.3, 'b5b69c', 10);
    const stripe = ['ede4bf', 'cc553d', 'ebe2bd', 'cd5339', 'f0e5c8'];
    for (let i = 0; i < 5; i++)
      tapered(x, y + 1.3 + i * 3.32, z, 3.03 - i * 0.21, 2.82 - i * 0.21, 3.32, stripe[i], 10);
    tapered(x, y + 17.87, z, 2.97, 2.97, 0.72, '304f51', 10);
    tapered(x, y + 18.6, z, 1.93, 1.93, 2.65, '81c9c4', 8);
    material = 2;
    tapered(x, y + 19.15, z, 2.01, 2.01, 0.84, 'ffe699', 8);
    material = 0;
    for (let i = 0; i < 8; i++) {
      const a = (i * PI) / 4;
      box(x + sin(a) * 2, y + 18.55, z + cos(a) * 2, 0.14, 2.72, 0.14, '304c4d');
    }
    tapered(x, y + 21.28, z, 2.8, 0.48, 1.75, 'b84e37', 8);
    tapered(x, y + 23, z, 0.14, 0.14, 1.9, '314f50', 5);
    for (let i = 0; i < 3; i++) box(x, y + 3 + i * 5, z - 2.78 + i * 0.23, 0.75, 1.18, 0.16, '384e52');
  }
  function setWorld(w) {
    world = w;
    verts = [];
    material = 1;
    face(
      [-1150, -0.55, -1150],
      [1150, -0.55, -1150],
      [1150, -0.55, 1150],
      [-1150, -0.55, 1150],
      '5aa6aa',
      [0, 1, 0],
    );
    material = 0;
    const rand = w.rng(w.seed ^ 301);
    material = 3;
    for (let j = 0; j < w.n; j++)
      for (let i = 0; i < w.n; i++) {
        const x = i * w.step - w.edge,
          z = j * w.step - w.edge,
          o = j * (w.n + 1) + i,
          s = w.step;
        const a = [x, w.heights[o], z],
          b = [x + s, w.heights[o + 1], z],
          c = [x, w.heights[o + w.n + 1], z + s],
          d = [x + s, w.heights[o + w.n + 2], z + s];
        if (Math.max(a[1], b[1], c[1], d[1]) < -0.68) continue;
        const grass = w.terrainColor(3, x, z);
        tri(a, b, d, scale(grass, 0.977 + rand() * 0.039), [0, 1, 0]);
        tri(a, d, c, scale(grass, 0.977 + rand() * 0.039), [0, 1, 0]);
      }
    material = 0;
    for (const path of w.paths) {
      const points = [];
      for (let i = 1; i < path.length; i++) {
        const [x, z] = path[i - 1],
          [xx, zz] = path[i],
          steps = Math.ceil(Math.hypot(xx - x, zz - z) / 1.3);
        for (let j = 0; j < steps; j++)
          points.push([x + ((xx - x) * j) / steps, z + ((zz - z) * j) / steps]);
      }
      points.push(path[path.length - 1]);
      let last;
      for (let i = 0; i < points.length; i++) {
        const prev = points[Math.max(0, i - 1)],
          next = points[Math.min(points.length - 1, i + 1)],
          dx = next[0] - prev[0],
          dz = next[1] - prev[1],
          len = Math.hypot(dx, dz) || 1;
        const strip = [-1, 0, 1].map((k) => {
          const off = k * (1.56 + sin(i * 0.32) * 0.12),
            x = points[i][0] + (dz / len) * off,
            z = points[i][1] - (dx / len) * off;
          return [x, w.ground(x, z) + 0.075, z];
        });
        if (last)
          for (let j = 0; j < 2; j++)
            face(last[j], last[j + 1], strip[j + 1], strip[j], 'b5ab77', [0, 1, 0]);
        last = strip;
      }
    }
    for (let i = 0; i < 42; i++) {
      const a = (i * TAU) / 42 + 0.05 * rand(),
        r = 420 + rand() * 150;
      tapered(
        sin(a) * r,
        -17,
        cos(a) * r,
        42 + rand() * 75,
        0,
        30 + rand() * 70,
        '839b9c',
        5,
        rand() * 2,
        1.1,
      );
    }
    for (const o of w.props) {
      if (o.type === 'tree') {
        shadow(
          o.x + 0.55,
          o.z - 0.2,
          o.r * 1.15,
          o.r * 0.83,
          scale(w.terrainColor(o.y, o.x, o.z), 0.8),
          w.ground,
        );
        const aspen = o.t > 0.75 && o.y < 19;
        tapered(
          o.x,
          o.y - 0.3,
          o.z,
          0.33,
          0.22,
          o.h * (aspen ? 0.72 : 0.5),
          aspen ? 'b4ab88' : '756447',
          6,
          o.t,
        );
        if (aspen) {
          const leaf = o.t > 0.88 ? ['849657', 'b0ae62', 'c2b869'] : ['718953', '90a25f', 'a0b374'];
          for (let k = 0; k < 3; k++) {
            const a = o.t * 9 + k * 2.18,
              w = o.r * (k === 2 ? 0.91 : 0.81),
              x = o.x + (k === 2 ? 0 : cos(a) * o.r * 0.52),
              z = o.z + (k === 2 ? 0 : sin(a) * o.r * 0.45),
              y = o.y + o.h * (k === 2 ? 0.61 : 0.43);
            tapered(x, y, z, w * 0.3, w, o.h * 0.19, leaf[k], 6, a, 0.89);
            tapered(x, y + o.h * 0.19, z, w, w * 0.22, o.h * 0.22, leaf[k], 6, a, 0.89);
          }
          continue;
        }
        const forest = o.t > 0.56 ? ['316453', '38765d', '53896a'] : ['315e51', '3d7159', '527e60'];
        tapered(o.x, o.y + o.h * 0.24, o.z, o.r, 0, o.h * 0.54, forest[0], 7, o.t);
        tapered(o.x, o.y + o.h * 0.44, o.z, o.r * 0.81, 0, o.h * 0.48, forest[1], 7, o.t + 0.3);
        tapered(o.x, o.y + o.h * 0.62, o.z, o.r * 0.57, 0, o.h * 0.43, forest[2], 7, o.t);
      } else if (o.type === 'rock') {
        tapered(o.x, o.y - 0.5, o.z, o.w * 0.86, o.w, o.h * 0.54, '7f8981', 6, o.t, o.d / o.w);
        tapered(o.x, o.y - 0.5 + o.h * 0.54, o.z, o.w, o.w * 0.44, o.h * 0.59, '9aa196', 6, o.t, o.d / o.w);
      } else if (o.type === 'cabin') drawCabin(o);
      else lighthouse(o);
    }
    for (let i = 0; i < 860; i++) {
      const x = rand() * 235 - 117,
        z = rand() * 235 - 117,
        y = w.ground(x, z);
      if (y < 2.4 || !w.clear(x, z, 0)) continue;
      const size = 0.16 + rand() * 0.3,
        tint = rand() < 0.17 ? 'dfb66a' : '65824c';
      for (let j = 0; j < 3; j++) {
        const xx = x + (j - 1) * size;
        tri(
          [xx - size * 0.28, y - 0.03, z],
          [xx + size * 0.4, y - 0.03, z],
          [xx + size * 0.25, y + size * (0.8 + rand()), z + 0.1],
          tint,
          [0, 1, -1],
        );
      }
    }
    for (let i = 0; i < 5; i++) {
      const x = -109 + i * 3,
        z = 79 - i * 0.2,
        y = w.ground(x, z);
      if (y > 1) continue;
      tapered(x, -1, z, 0.31, 0.26, 2.4, '7a6650', 6);
      if (i < 4) box(x + 1.4, 1.22, z, 3.4, 0.25, 2.7, 'b39870');
    }
    staticCount = verts.length / 10;
    gl.bindBuffer(gl.ARRAY_BUFFER, staticBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(verts), gl.STATIC_DRAW);
    verts = [];
  }
  const suits = [
    'f27b43',
    '47c7ba',
    'e7b859',
    '91a5e2',
    'd87978',
    '8ab873',
    '65a6c3',
    'bc8bd5',
    'de915e',
    '67b396',
    'bab668',
    'da9987',
  ];
  function avatar(p, index, time) {
    if (p.hp <= 0) return;
    const a = p.yaw,
      c = cos(a),
      s = sin(a),
      suit = suits[index % suits.length],
      y = p.y;
    const at = (u, h, v) => [p.x + u * c + v * s, y + h, p.z - u * s + v * c];
    const part = (u, h, v, w, hh, d, col) => {
      const k = at(u, h, v);
      box(k[0], k[1], k[2], w, hh, d, col, a);
    };
    const step = p.glide ? 0.07 : Math.sin(time * 9 + index) * Math.min(0.2, p.move * 0.032);
    for (const side of [-1, 1]) {
      const k = side * step;
      beam(at(side * 0.16, 0.87, 0), at(side * 0.18, 0.4, k), 0.145, '3e5360');
      beam(at(side * 0.18, 0.4, k), at(side * 0.18, 0.12, k * 1.4), 0.105, '42555a');
      part(side * 0.18, 0.02, k * 1.4 + 0.05, 0.235, 0.17, 0.33, '293d43');
    }
    part(0, 0.77, 0, 0.65, 0.74, 0.42, suit);
    part(0, 0.8, -0.015, 0.66, 0.14, 0.45, '394e52');
    part(0, 1.42, 0, 0.37, 0.17, 0.34, '304b50');
    part(0, 1.53, 0, 0.44, 0.4, 0.43, suit);
    part(0, 1.77, 0, 0.49, 0.18, 0.47, '334f55');
    part(0, 1.66, 0.213, 0.38, 0.14, 0.075, 'b6e4d9');
    part(0, 1.64, -0.232, 0.39, 0.09, 0.07, '273e43');
    part(0, 1.03, -0.29, 0.48, 0.5, 0.23, '43595a');
    part(0, 1.34, -0.32, 0.48, 0.12, 0.25, 'd7c49b');
    part(-0.17, 0.98, -0.4, 0.09, 0.35, 0.09, 'd2b282');
    for (const side of [-1, 1]) {
      beam(at(side * 0.34, 1.4, 0), at(side * 0.43, 1.08, 0.12), 0.126, suit);
      beam(at(side * 0.43, 1.08, 0.12), at(side * 0.24, 1.2, side > 0 ? 0.44 : 0.55), 0.104, '3b5052');
    }
    part(0.24, 1.22, 0.55, 0.14, 0.16, 0.66, '293e46');
    part(0.24, 1.21, 0.91, 0.1, 0.1, 0.34, '697b78');
    if (p.glide) {
      const fold = [-3.25, -2.1, -1, 0, 1, 2.1, 3.25];
      const row = (w, front) =>
        at(
          w,
          3.59 + 0.72 * (1 - Math.pow(Math.abs(w) / 3.25, 1.7)) + (front ? 0.12 : 0),
          front ? 0.95 - Math.abs(w) * 0.21 : -0.72 - Math.abs(w) * 0.14,
        );
      for (let i = 0; i < 6; i++)
        face(
          row(fold[i], false),
          row(fold[i + 1], false),
          row(fold[i + 1], true),
          row(fold[i], true),
          i === 1 || i === 4 ? 'f7e4b3' : i === 2 || i === 3 ? suit : '365857',
          [0, 1, 0],
        );
      for (const side of [-1, 1]) {
        beam(at(side * 0.33, 1.36, 0.1), row(side * 3.08, false), 0.024, '384e52', 3);
        beam(at(side * 0.33, 1.36, 0.1), row(side * 2.15, true), 0.024, '384e52', 3);
      }
    }
  }
  function crate(c, opened, time) {
    const { x, y, z } = c;
    box(x, y - 0.04, z, 1.32, 0.83, 0.94, opened ? '786950' : 'bd823c');
    box(
      x,
      y + 0.71,
      z + (opened ? 0.35 : 0),
      1.39,
      opened ? 0.16 : 0.27,
      0.99,
      opened ? 'a38657' : 'deb15b',
    );
    for (const v of [-0.45, 0.45]) box(x + v, y, z, 0.105, 0.94, 0.97, '465a52');
    if (!opened) {
      material = 2;
      box(x, y + 0.41, z - 0.51, 0.23, 0.25, 0.065, 'ffdf86');
      material = 0;
      const t = 0.9 + sin(time * 2 + c.id) * 0.16;
      tapered(x, y + t + 0.43, z, 0.12, 0, 0.22, 'ffcf6d', 4, time * 0.7);
      tapered(x, y + t + 0.25, z, 0, 0.12, 0.18, 'eac778', 4, time * 0.7);
    }
  }
  function structure(b, ghost = false) {
    const a = (b.dir * PI) / 2,
      c = cos(a),
      s = sin(a),
      wood = ghost ? '80f2d4' : 'b7895e',
      light = ghost ? 'b4fff3' : 'd6ae7a';
    const at = (u, h, v) => [b.x + u * c + v * s, b.y + h, b.z - u * s + v * c];
    if (b.kind === 'wall') {
      for (let i = 0; i < 8; i++) {
        const k = at(-1.75 + i * 0.5, 0, 0);
        box(...k, 0.475, 3.26, 0.2, i % 3 === 0 ? light : wood, a);
      }
      for (const z of [-0.15, 0.15]) beam(at(-1.9, 0.22, z), at(1.9, 3.04, z), 0.14, light, 4);
    } else if (b.kind === 'floor') {
      for (let i = 0; i < 8; i++) {
        const k = at(-1.75 + i * 0.5, 0, 0);
        box(...k, 0.47, 0.22, 4, wood, a);
      }
    } else {
      for (let i = 0; i < 9; i++) {
        const v = -1.78 + i * 0.445,
          h = (v + 2) * 0.8125;
        const k = at(0, h - 0.1, v);
        box(...k, 4, 0.18, 0.49, i % 3 === 0 ? light : wood, a);
      }
      for (const side of [-1.78, 1.78]) beam(at(side, 0, -2), at(side, 3.23, 2), 0.16, wood, 4);
    }
  }
  function vars(pr, cam, lens, t) {
    const cp = cos(cam.pitch),
      sp = sin(cam.pitch),
      cy = cos(cam.yaw),
      sy = sin(cam.yaw);
    gl.uniform3f(pr.forward, sy * cp, sp, cy * cp);
    gl.uniform3f(pr.right, cy, 0, -sy);
    gl.uniform3f(pr.up, -sy * sp, cp, -cy * sp);
    gl.uniform3fv(pr.eye, cam.pos);
    gl.uniform2fv(pr.lens, lens);
    gl.uniform1f(pr.clock, t);
  }
  function mesh(buffer, count, alpha) {
    if (!count) return;
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    for (const [idx, size, offset] of [
      [scene.pos, 3, 0],
      [scene.norm, 3, 12],
      [scene.col, 3, 24],
      [scene.mat, 1, 36],
    ]) {
      gl.enableVertexAttribArray(idx);
      gl.vertexAttribPointer(idx, size, gl.FLOAT, false, 40, offset);
    }
    gl.uniform1f(scene.alpha, alpha);
    gl.drawArrays(gl.TRIANGLES, 0, count);
  }
  function flush(buffer, alpha) {
    const data = new Float32Array(verts);
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.DYNAMIC_DRAW);
    mesh(buffer, verts.length / 10, alpha);
    verts = [];
  }
  function render(cam, snap, fx, ghost, t, zoom) {
    const ratio = Math.min(window.devicePixelRatio || 1, 1.5, 1920 / Math.max(1, canvas.clientWidth));
    const w = Math.max(1, Math.round(canvas.clientWidth * ratio)),
      h = Math.max(1, Math.round(canvas.clientHeight * ratio));
    if (w !== canvas.width || h !== canvas.height) {
      canvas.width = w;
      canvas.height = h;
    }
    const fov = zoom ? 0.44 : 0.64,
      lens = [(fov * w) / h, fov];
    gl.viewport(0, 0, w, h);
    gl.clearDepth(1);
    gl.clear(gl.DEPTH_BUFFER_BIT);
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.BLEND);
    gl.useProgram(sky.p);
    gl.bindBuffer(gl.ARRAY_BUFFER, quad);
    for (const k of [scene.pos, scene.norm, scene.col, scene.mat]) gl.disableVertexAttribArray(k);
    gl.enableVertexAttribArray(sky.a);
    gl.vertexAttribPointer(sky.a, 2, gl.FLOAT, false, 0, 0);
    vars(sky, cam, lens, t);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.disableVertexAttribArray(sky.a);
    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);
    gl.useProgram(scene.p);
    vars(scene, cam, lens, t);
    mesh(staticBuffer, staticCount, 1);
    verts = [];
    if (snap) {
      for (const b of snap.builds) structure(b);
      for (let i = 0; i < snap.players.length; i++) {
        const p = snap.players[i];
        if (p.hp <= 0) continue;
        if (!p.glide && Math.hypot(p.x - cam.pos[0], p.z - cam.pos[2]) < 65)
          shadow(
            p.x,
            p.z,
            0.57,
            0.43,
            scale(world.terrainColor(world.ground(p.x, p.z), p.x, p.z), 0.69),
            world.ground,
          );
        if (Math.hypot(cam.pos[0] - p.x, cam.pos[1] - p.y - 1.55, cam.pos[2] - p.z) > 0.9) avatar(p, i, t);
      }
    }
    const opened = new Set(snap?.opened || []);
    for (const c of world.caches)
      if (Math.hypot(c.x - cam.pos[0], c.z - cam.pos[2]) < 135) crate(c, opened.has(c.id), t);
    material = 2;
    for (const e of fx) {
      for (const end of e.ends) beam(e.origin, end, 0.025, 'ffe390', 4);
      const o = e.origin;
      tapered(o[0], o[1] - 0.09, o[2], 0.1, 0, 0.22, 'fff0af', 5, t * 8);
    }
    material = 0;
    flush(dynamicBuffer, 1);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.depthMask(false);
    if (ghost) {
      material = 2;
      structure(ghost, true);
      material = 0;
      flush(veilBuffer, 0.48);
    }
    const st = snap?.storm;
    if (st && st.r > 0.2) {
      material = 2;
      for (let i = 0; i < 76; i++) {
        const a = (i * TAU) / 76,
          b = ((i + 1) * TAU) / 76,
          point = (angle, y) => [st.x + sin(angle) * st.r, y, st.z + cos(angle) * st.r];
        face(point(a, -1), point(b, -1), point(b, 59), point(a, 59), '9d94e2', [0, 1, 0]);
      }
      flush(veilBuffer, 0.14);
      for (let i = 0; i < 76; i++) {
        const a = (i * TAU) / 76,
          b = ((i + 1) * TAU) / 76;
        for (const y of [3, 12]) {
          const y1 = y + sin(a * 6 + t) * 1.3,
            y2 = y + sin(b * 6 + t) * 1.3;
          face(
            [st.x + sin(a) * st.r, y1, st.z + cos(a) * st.r],
            [st.x + sin(b) * st.r, y2, st.z + cos(b) * st.r],
            [st.x + sin(b) * st.r, y2 + 0.23, st.z + cos(b) * st.r],
            [st.x + sin(a) * st.r, y1 + 0.23, st.z + cos(a) * st.r],
            'bfafff',
            [0, 1, 0],
          );
        }
      }
      material = 0;
      flush(veilBuffer, 0.46);
    }
    gl.depthMask(true);
    gl.disable(gl.BLEND);
  }
  return { setWorld, render };
}

function gamePage() {
  const icons = {
    mark: '<path d="M1 22 11 3h6L7 22zM12 22l7-13 7 13h-6l-2-4-2 4z" fill="currentColor"/>',
    sound: '<path d="M3 9h4l5-4v14l-5-4H3zm13-1c2 2 2 6 0 8m3-10c4 4 4 8 0 12"/>',
    keys: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M5 9h2m2 0h2m2 0h2m2 0h2M5 12h2m2 0h2m2 0h2m2 0h2M7 15h10"/>',
    people:
      '<circle cx="10" cy="8" r="3"/><path d="M3 19c0-4 3-6 7-6s7 2 7 6m0-14c4 0 4 6 1 6m1 3c2 1 3 2 3 5"/>',
    aim: '<circle cx="12" cy="12" r="6"/><path d="M12 2v5m0 10v5M2 12h5m10 0h5"/>',
    storm: '<path d="m13 2-9 12h7l-1 8 10-14h-8z"/>',
    shield: '<path d="M12 3 4 6v6c0 5 5 8 8 10 3-2 8-5 8-10V6z"/>',
    cross: '<path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6z"/>',
    wood: '<path d="m3 15 11-10 7 3-11 11zM3 15v3l7 3v-2m0 2 11-10V8"/>',
    carbine:
      '<path d="m2 13 3-3h7l1-2h4v2h6v2h-8l-2 4h-3l1-4H8l-4 4H2z" fill="currentColor" stroke="none"/>',
    shotgun:
      '<path d="m1 15 5-5h16v2H10l-1 2H7l-3 4z" fill="currentColor" stroke="none"/><path d="M11 13h9"/>',
    tonic: '<path d="M9 3h6v3H9zm-1 5h8l2 4v7l-2 2H8l-2-2v-7z"/><path d="M8 15h8"/>',
    arrow: '<path d="M3 12h16m-6-6 6 6-6 6"/>',
    flag: '<path d="M5 22V3m1 1c4-3 7 3 15 0v10c-6 3-9-3-15 0"/>',
  };
  const ic = (id, size = 18) =>
    '<svg width="' +
    size +
    '" height="' +
    size +
    '" viewBox="0 0 ' +
    (id === 'mark' ? '28 26' : '24 24') +
    '" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
    icons[id] +
    '</svg>';
  const controls = [
    ['Move / sprint', 'W A S D / Shift'],
    ['Look', 'Mouse or arrow keys'],
    ['Fire / aim', 'Left or Enter / right mouse'],
    ['Jump / reload', 'Space / R'],
    ['Carbine / shotgun / tonic', '1 / 2 / 3'],
    ['Use a shield tonic', '3, then fire'],
    ['Open crate / harvest tree', 'E / F'],
    ['Toggle build mode', 'Q'],
    ['Wall / ramp / floor', 'Z / X / C'],
    ['Place selected piece', 'Left mouse'],
    ['Tactical map / field menu', 'M / Esc or P'],
  ];
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
    <meta name="theme-color" content="#163c3c" />
    <title>Breakwater Royale — Kestrel Isle</title>
    <style>
      :root {
        --ink: #102b2e;
        --panel: #11363a;
        --paper: #f3f2dd;
        --mute: #a6c3b8;
        --mint: #9de0bd;
        --gold: #f5bd64;
        --orange: #ffb24d;
        --mono: ui-monospace, "SFMono-Regular", Consolas, monospace;
        --display: Impact, Haettenschweiler, "Arial Narrow Bold", system-ui, sans-serif;
      }
      * {
        box-sizing: border-box;
      }
      [hidden] {
        display: none !important;
      }
      html,
      body {
        margin: 0;
        width: 100%;
        height: 100%;
        overflow: hidden;
        background: #173f40;
        color: var(--paper);
        font:
          15px/1.4 system-ui,
          -apple-system,
          "Segoe UI",
          sans-serif;
      }
      button,
      input {
        font: inherit;
      }
      button {
        cursor: pointer;
        color: inherit;
      }
      button:focus-visible,
      input:focus-visible {
        outline: 3px solid var(--gold);
        outline-offset: 3px;
      }
      button:disabled {
        opacity: 0.55;
        cursor: wait;
      }
      button svg {
        flex-shrink: 0;
      }
      button {
        touch-action: manipulation;
      }
      #world,
      #landing,
      #game,
      #shade,
      #effect {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
      }
      #world {
        display: block;
        touch-action: none;
      }
      #landing {
        pointer-events: none;
        display: flex;
        flex-direction: column;
        isolation: isolate;
      }
      #shade {
        z-index: -1;
        background:
          linear-gradient(
            90deg,
            rgba(9, 35, 39, 0.98) 0%,
            rgba(12, 43, 45, 0.94) 20%,
            rgba(15, 48, 49, 0.73) 38%,
            rgba(18, 50, 48, 0.12) 65%,
            transparent 86%
          ),
          linear-gradient(
            0deg,
            rgba(8, 34, 38, 0.76),
            transparent 27%,
            transparent 83%,
            rgba(16, 45, 45, 0.26)
          );
      }
      .wrap {
        width: 100%;
        padding: 0 clamp(24px, 5vw, 90px);
      }
      header {
        height: 82px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        border-bottom: 1px solid #e0f1dc35;
      }
      .brand {
        display: flex;
        align-items: center;
        gap: 10px;
        font: 850 14px/1 system-ui;
        letter-spacing: 0.12em;
      }
      .mark {
        width: 39px;
        height: 39px;
        display: grid;
        place-items: center;
        background: var(--gold);
        color: var(--ink);
        border-radius: 3px;
        transform: skew(-5deg);
      }
      .brand small {
        border-left: 1px solid #d0e1d180;
        padding-left: 14px;
        margin-left: 4px;
      }
      .mono,
      .over,
      .tag,
      .minihead,
      .badge,
      .hudlabel,
      .readout,
      .chip,
      .key,
      .hudkey {
        font-family: var(--mono);
        text-transform: uppercase;
        letter-spacing: 0.12em;
      }
      .over,
      .tag,
      .minihead,
      .badge,
      .hudlabel,
      .readout,
      .chip,
      .key,
      .hudkey,
      .brand small {
        font-size: 10px;
        font-weight: 750;
      }
      .top-actions {
        pointer-events: auto;
        display: flex;
        gap: 8px;
      }
      .topbtn,
      .flat,
      .close,
      .specnext {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        background: #153937ae;
        border: 1px solid #c5dcc54d;
        border-radius: 4px;
        padding: 9px 13px;
        font-weight: 650;
        font-size: 12px;
      }
      .topbtn:hover,
      .flat:hover,
      .close:hover,
      .specnext:hover {
        background: #325852;
      }
      main {
        display: flex;
        align-items: center;
        flex: 1;
        min-height: 0;
      }
      .content {
        pointer-events: auto;
        width: min(470px, 100%);
        padding: 12px 0;
      }
      .over {
        display: flex;
        align-items: center;
        gap: 9px;
        color: #d2e3c7;
        font-size: 11px;
      }
      .over i,
      .dot {
        display: inline-block;
        background: var(--mint);
        width: 7px;
        height: 7px;
        border-radius: 50%;
        box-shadow: 0 0 13px #a1f2ae77;
      }
      .hero-title {
        font: 1000 italic clamp(68px, min(8vw, 11.2vh), 142px) / 0.82 var(--display);
        letter-spacing: -0.085em;
        transform: skew(-5deg);
        transform-origin: left;
        margin: 17px 0 18px -3px;
        text-shadow: 0 4px 0 #113b382e;
      }
      .hero-title em {
        color: var(--gold);
        font-style: inherit;
      }
      .hero-sub {
        font-size: clamp(14px, 1.35vw, 18px);
        color: #e3e9d6;
        line-height: 1.45;
        max-width: 390px;
        margin: 0 0 24px;
      }
      .form {
        width: min(344px, 100%);
      }
      .namelabel {
        display: block;
        color: #b8cfc0;
        font: 700 10px var(--mono);
        letter-spacing: 0.15em;
        margin-bottom: 6px;
      }
      .namebox {
        display: flex;
        align-items: center;
        background: #0b2d30b8;
        border: 1px solid #9eb9aa70;
        border-radius: 4px;
        padding: 0 12px;
        gap: 9px;
      }
      .namebox input,
      .codein {
        color: var(--paper);
        background: transparent;
        border: 0;
        outline: 0;
        width: 100%;
        height: 38px;
      }
      .namebox:focus-within {
        border-color: var(--mint);
      }
      .namebox svg {
        color: #9cbdad;
      }
      .primary {
        display: flex;
        width: 100%;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        border: 0;
        border-radius: 4px;
        background: var(--gold);
        color: #172c2b;
        padding: 13px 17px;
        font-weight: 850;
        box-shadow: inset 0 -3px 0 #d68a4099;
        transition:
          background 0.12s,
          transform 0.12s;
      }
      .primary:hover {
        background: #ffd084;
        transform: translateY(-1px);
      }
      .primary:active {
        transform: translateY(1px);
      }
      .form .primary {
        margin: 9px 0;
      }
      .row {
        display: flex;
        gap: 7px;
      }
      .row > .flat {
        flex: 1;
        white-space: nowrap;
      }
      .flat {
        padding: 9px 10px;
      }
      .smallnote {
        color: #bdd1c4;
        font-size: 12px;
        line-height: 1.45;
      }
      .error {
        color: #ffcc94;
      }
      .empty:empty {
        display: none;
      }
      .roomcode {
        font: 850 26px var(--mono);
        letter-spacing: 0.14em;
        color: var(--gold);
        user-select: all;
      }
      .modes h2,
      .dialog h2 {
        font: 900 italic clamp(30px, 4vw, 44px) / 1.02 var(--display);
        letter-spacing: -0.045em;
        margin: 10px 0 12px;
      }
      .modes {
        max-width: 360px;
      }
      .modes .row,
      .modes .primary {
        margin-top: 10px;
      }
      .modes p {
        color: #d0e0cf;
      }
      .codein {
        display: block;
        border: 1px solid #a7bcab80;
        background: #153939b0;
        padding: 0 12px;
        text-transform: uppercase;
        font-family: var(--mono);
        letter-spacing: 0.14em;
      }
      .roster {
        display: flex;
        flex-wrap: wrap;
        gap: 5px;
        margin: 12px 0;
      }
      .chip {
        background: #386058;
        border: 1px solid #92b4a05c;
        border-radius: 3px;
        padding: 3px 6px;
        letter-spacing: 0.04em;
        color: #eff1d7;
      }
      .atlas {
        position: absolute;
        right: 5vw;
        bottom: 19%;
        display: flex;
        align-items: center;
        gap: 12px;
        text-shadow: 0 1px 8px #052c32aa;
      }
      .atlas .line {
        width: 50px;
        height: 1px;
        background: #e5ecd1;
      }
      .atlas b {
        display: block;
        font-size: 17px;
        font-style: italic;
      }
      .atlas small {
        font: 700 10px var(--mono);
        letter-spacing: 0.15em;
      }
      .foot {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        height: 49px;
        color: #d4e1ce;
        border-top: 1px solid #c6dac441;
        font: 650 10px var(--mono);
        letter-spacing: 0.12em;
      }
      .foot > span {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .layer {
        position: absolute;
        inset: 0;
        display: grid;
        place-items: center;
        background: #092629ae;
        z-index: 20;
        padding: 18px;
      }
      .dialog {
        position: relative;
        width: min(430px, 100%);
        padding: 27px;
        background: linear-gradient(145deg, #214d49, #123338);
        border: 1px solid #a3c3a966;
        border-radius: 9px;
        box-shadow: 0 12px 60px #00151777;
      }
      .dialog p {
        color: #c9dccd;
      }
      .dialog .close {
        position: absolute;
        right: 12px;
        top: 12px;
        font-size: 17px;
        padding: 2px 10px;
      }
      .controlslist {
        margin: 14px 0 0;
        max-height: 59vh;
        overflow: auto;
      }
      .controlslist div {
        display: flex;
        justify-content: space-between;
        gap: 10px;
        padding: 5px 0;
        border-bottom: 1px solid #bfd9c027;
        font-size: 13px;
      }
      .controlslist kbd,
      .hudkey,
      .key {
        background: #e9f2d718;
        color: #e3e9d8;
        border: 1px solid #ddebd64c;
        border-radius: 3px;
        padding: 2px 5px;
        font-family: var(--mono);
        white-space: nowrap;
      }
      .dialog .row {
        margin-top: 12px;
      }
      .dialog .row button {
        flex: 1;
      }
      #game {
        pointer-events: none;
        z-index: 3;
        text-shadow: 0 1px 4px #092b31b0;
      }
      .glass {
        background: linear-gradient(115deg, #103336ec, #12373cd6);
        border: 1px solid #c0ddc34f;
        border-radius: 5px;
        box-shadow: 0 4px 17px #062a2b35;
      }
      .hudlabel {
        color: #b6cdc0;
        letter-spacing: 0.11em;
        font-size: 9px;
      }
      .top-left {
        position: absolute;
        left: 22px;
        top: 18px;
        min-width: 160px;
        padding: 10px 13px;
      }
      .top-left b {
        font-size: 18px;
        font-style: italic;
      }
      .statusline {
        display: flex;
        align-items: center;
        gap: 7px;
        margin-top: 4px;
        font: 650 11px var(--mono);
        color: #c6d8c9;
      }
      .statusline svg {
        color: #cbadef;
      }
      .compass {
        position: absolute;
        left: 50%;
        top: 20px;
        transform: translateX(-50%);
        background: linear-gradient(90deg, transparent, #163b40ad 28%, #163b40ad 72%, transparent);
        padding: 3px 14px;
        text-align: center;
        white-space: pre;
        font: 750 12px var(--mono);
        letter-spacing: 0.06em;
      }
      .compass:after {
        content: "";
        display: block;
        width: 0;
        margin: 3px auto 0;
        border-left: 4px solid transparent;
        border-right: 4px solid transparent;
        border-bottom: 5px solid var(--gold);
      }
      .miniblock {
        position: absolute;
        right: 22px;
        top: 18px;
        width: 148px;
        padding: 5px 5px 3px;
      }
      .miniblock canvas {
        width: 100%;
        height: auto;
        display: block;
        border-radius: 3px;
      }
      .mapline {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 4px 2px 1px;
        font: 750 11px var(--mono);
      }
      .mapline span {
        display: inline-flex;
        align-items: center;
        gap: 3px;
      }
      .mapline svg {
        width: 14px;
        height: 14px;
        color: var(--mint);
      }
      .feed {
        position: absolute;
        top: 106px;
        left: 23px;
        max-width: 260px;
        display: grid;
        gap: 3px;
      }
      .feed div {
        font-size: 11px;
        padding: 3px 7px;
        background: #11343ac9;
        border-left: 2px solid var(--gold);
        width: fit-content;
      }
      .vitals {
        position: absolute;
        left: 22px;
        bottom: 23px;
        width: min(260px, 28vw);
        padding: 11px 13px;
      }
      .vitalname {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 6px;
      }
      .vitalname b {
        font-size: 14px;
      }
      .bar {
        display: flex;
        align-items: center;
        gap: 6px;
        margin: 4px 0;
        color: #b4dafa;
      }
      .bar.health {
        color: #9ce0a4;
      }
      .bar svg {
        width: 13px;
        height: 13px;
      }
      .bar i {
        flex: 1;
        background: #0c272b;
        border-radius: 1px;
        display: block;
        height: 8px;
        overflow: hidden;
      }
      .bar i em {
        display: block;
        height: 100%;
        width: 0;
        background: currentColor;
        transition: width 0.12s;
      }
      .bar strong {
        font: 750 12px var(--mono);
        min-width: 25px;
        text-align: right;
        color: var(--paper);
      }
      .netline {
        font: 650 9px var(--mono);
        letter-spacing: 0.07em;
        color: #aec6b7;
        margin-top: 6px;
      }
      .gear {
        position: absolute;
        right: 22px;
        bottom: 22px;
        text-align: right;
      }
      .slots {
        display: flex;
        justify-content: flex-end;
        gap: 4px;
      }
      .slot {
        position: relative;
        min-width: 67px;
        color: #bcd0ca;
        background: #183b40da;
        border: 1px solid #a1c0ac70;
        border-bottom: 3px solid #92aaa1;
        border-radius: 4px;
        display: grid;
        grid-template-columns: auto 1fr;
        align-items: center;
        gap: 4px;
        padding: 4px 8px 5px;
        font: 750 10px var(--mono);
        pointer-events: auto;
      }
      .slot.sel {
        color: #fff2bd;
        border-color: var(--gold);
        background: #615639e8;
      }
      .slot b {
        align-self: start;
        font-size: 10px;
      }
      .slot svg {
        width: 31px;
        height: 25px;
      }
      .geartop {
        display: flex;
        justify-content: flex-end;
        align-items: baseline;
        gap: 8px;
        margin-bottom: 4px;
      }
      .geartop strong {
        font: 900 italic 29px var(--display);
        color: #fff2c6;
      }
      .geartop span {
        font: 750 10px var(--mono);
      }
      .gearnote {
        font: 700 10px var(--mono);
        margin-top: 5px;
      }
      .reticle {
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        width: 23px;
        height: 23px;
        background:
          linear-gradient(white, white) center top/2px 6px,
          linear-gradient(white, white) center bottom/2px 6px,
          linear-gradient(white, white) left center/6px 2px,
          linear-gradient(white, white) right center/6px 2px;
        background-repeat: no-repeat;
        filter: drop-shadow(0 1px 1px #16363a);
      }
      .reticle.hit:after {
        content: "×";
        position: absolute;
        inset: -12px;
        text-align: center;
        color: #ffda76;
        font: 900 36px var(--mono);
      }
      .prompt {
        position: absolute;
        left: 50%;
        top: 59%;
        transform: translateX(-50%);
        padding: 5px 10px;
        border-radius: 3px;
        background: #15373dcf;
        color: #fff1cc;
        font: 750 11px var(--mono);
        white-space: nowrap;
      }
      .toast {
        position: absolute;
        left: 50%;
        bottom: 18%;
        transform: translateX(-50%);
        font: 800 12px var(--mono);
        color: #f8e5ad;
        text-align: center;
        text-shadow: 0 2px 5px #0d2b2e;
      }
      .tip {
        position: absolute;
        bottom: 27px;
        left: 50%;
        transform: translateX(-50%);
        padding: 5px 7px;
        text-align: center;
        font: 650 10px var(--mono);
        color: #f4efd5;
        background: #163638af;
        border-radius: 3px;
        white-space: nowrap;
      }
      #effect {
        z-index: 2;
        pointer-events: none;
        transition: background 0.13s;
      }
      .specnext {
        pointer-events: auto;
        position: absolute;
        left: 50%;
        top: 69%;
        transform: translateX(-50%);
      }
      #mapbox {
        max-width: min(540px, 88vh);
        padding: 17px;
      }
      #bigmap {
        display: block;
        width: 100%;
      }
      .maptitle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin: 4px 40px 6px 4px;
      }
      #touch {
        display: none;
        position: absolute;
        inset: 0;
        pointer-events: none;
      }
      .touchbtn,
      #stick {
        position: absolute;
        pointer-events: auto;
        touch-action: none;
        border: 1px solid #d4e8d173;
        border-radius: 50%;
        color: #f2f2df;
        background: #183d42b8;
        font: 750 11px var(--mono);
        width: 45px;
        height: 45px;
        display: grid;
        place-items: center;
      }
      .touchbtn:nth-of-type(1) {
        right: 18px;
        bottom: 121px;
        width: 62px;
        height: 62px;
      }
      .touchbtn:nth-of-type(2) {
        right: 87px;
        bottom: 137px;
      }
      .touchbtn:nth-of-type(3) {
        right: 33px;
        bottom: 192px;
      }
      .touchbtn:nth-of-type(4) {
        right: 86px;
        bottom: 197px;
      }
      .touchbtn:nth-of-type(5) {
        right: 141px;
        bottom: 145px;
      }
      #stick {
        left: 30px;
        bottom: 95px;
        width: 91px;
        height: 91px;
      }
      #stick i {
        width: 35px;
        height: 35px;
        background: #d6e9d377;
        border-radius: 50%;
      }
      #fatalbox {
        z-index: 40;
      }
      #fieldmenu {
        pointer-events: auto;
        float: right;
        margin: -3px -6px -4px 8px;
        padding: 1px 5px;
        border: 0;
        border-radius: 2px;
        background: #dbe7d51f;
        font-size: 12px;
      }
      .miniblock canvas {
        pointer-events: auto;
        cursor: pointer;
      }
      @media (max-width: 760px) {
        header {
          height: 59px;
        }
        .brand small,
        .atlas,
        .tip,
        .foot span:last-child {
          display: none;
        }
        .wrap {
          padding: 0 22px;
        }
        .topbtn {
          font-size: 0;
          gap: 0;
          padding: 8px;
        }
        .content {
          width: min(390px, 100%);
        }
        .hero-title {
          font-size: clamp(65px, 12vh, 98px);
        }
        .hero-sub {
          max-width: 310px;
        }
        .foot {
          height: 33px;
        }
        .compass {
          font-size: 10px;
          top: 10px;
        }
        .miniblock {
          width: 106px;
          right: 9px;
          top: 8px;
        }
        .top-left {
          top: 8px;
          left: 9px;
          min-width: 115px;
          padding: 5px 7px;
        }
        .top-left b {
          font-size: 14px;
        }
        .vitals {
          left: 9px;
          bottom: 9px;
          width: 155px;
          padding: 6px;
        }
        .gear {
          right: 9px;
          bottom: 9px;
        }
        .slot {
          min-width: 41px;
          padding: 2px 3px;
          gap: 1px;
        }
        .slot svg {
          width: 21px;
          height: 19px;
        }
        .feed {
          left: 9px;
          top: 72px;
        }
        .geartop strong {
          font-size: 20px;
        }
      }
      @media (pointer: coarse) {
        #touch {
          display: block;
        }
        .tip {
          display: none;
        }
      }
      @media (max-height: 590px) {
        header {
          height: 40px;
        }
        .mark {
          width: 29px;
          height: 29px;
        }
        .hero-title {
          font-size: 54px;
          line-height: 0.82;
          margin: 8px 0;
        }
        .hero-sub {
          margin: 0 0 9px;
          font-size: 13px;
        }
        .content {
          padding: 4px 0;
        }
        .form .primary {
          margin: 5px 0;
          padding: 7px 12px;
        }
        .namebox input {
          height: 27px;
        }
        .flat {
          padding: 5px;
        }
        .foot {
          height: 23px;
        }
        .modes h2 {
          font-size: 27px;
        }
        .topbtn {
          padding: 4px 8px;
        }
      }
    </style>
  </head>
  <body>
    <canvas id="world" aria-label="Three-dimensional island battlefield"></canvas>
    <div id="effect"></div>
    <section id="landing">
      <div id="shade"></div>
      <header class="wrap">
        <div class="brand">
          <span class="mark">${ic('mark', 26)}</span> BREAKWATER <small class="mono">FIELD NETWORK</small>
        </div>
        <div class="top-actions">
          <button id="sound" class="topbtn" aria-label="Toggle sound">
            ${ic('sound')} <span>Sound on</span></button
          ><button id="help" class="topbtn" aria-label="Controls">${ic('keys')} Controls</button>
        </div>
      </header>
      <main class="wrap">
        <div class="content">
          <div id="home">
            <div class="over"><i></i> FIELD SERIES &nbsp;/&nbsp; ISLAND 01</div>
            <h1 class="hero-title">BREAK<br />WATER<em>.</em></h1>
            <p class="hero-sub">Glide into Kestrel Isle. Scavenge, build cover, and outlast the tide.</p>
            <div class="form">
              <label class="namelabel" for="callsign">YOUR CALLSIGN</label>
              <div class="namebox">
                ${ic('flag', 16)}<input
                  id="callsign"
                  maxlength="16"
                  placeholder="Drifter"
                  autocomplete="off"
                  spellcheck="false"
                />
              </div>
              <button class="primary" id="find">Find match ${ic('arrow', 22)}</button>
              <div class="row">
                <button class="flat" id="practice">${ic('aim', 15)} Solo practice</button
                ><button class="flat" id="private">${ic('people', 16)} Private room</button>
              </div>
            </div>
          </div>
          <div id="privatebox" class="modes" hidden>
            <div class="over"><i></i> PRIVATE FREQUENCY</div>
            <h2>Squad up.<br />Drop as rivals.</h2>
            <p>Create a room and share its six-character code, or join a friend before they launch.</p>
            <button class="primary" id="create">Create room ${ic('arrow')}</button
            ><label for="roominput" class="namelabel" style="margin-top: 18px">ROOM CODE</label
            ><input id="roominput" class="codein" placeholder="ABC234" maxlength="6" autocomplete="off" />
            <div class="row">
              <button class="flat" id="back">Back</button
              ><button class="flat" id="joincode">Join code</button>
            </div>
          </div>
          <div id="queue" class="modes" hidden>
            <div class="over"><i></i> FIELD NETWORK &nbsp;/&nbsp; MATCHMAKING</div>
            <h2 id="qtitle">Finding a match</h2>
            <p id="qstatus"></p>
            <div class="roomcode" id="rcode"></div>
            <div class="roster" id="roster"></div>
            <button class="primary" id="launch" hidden>Launch round ${ic('arrow')}</button>
            <div class="row"><button class="flat" id="cancel">Leave queue</button></div>
          </div>
          <p id="lobbymsg" class="smallnote error empty" role="status"></p>
        </div>
      </main>
      <div class="atlas">
        <span class="line"></span>
        <div><small>KESTREL ARCHIPELAGO &nbsp; / &nbsp; 01</small><b>Relay Point Lighthouse</b></div>
      </div>
      <footer class="wrap foot">
        <span><i class="dot"></i> SOLO ROYALE &nbsp;·&nbsp; 12 CONTENDERS</span
        ><span>KESTREL ISLE &nbsp; // &nbsp; FIELD BUILD 01</span>
      </footer>
    </section>
    <section id="game" hidden>
      <div class="glass top-left">
        <div class="hudlabel">
          FIELD 01 &nbsp;/&nbsp; SOLO ROYALE <button id="fieldmenu" aria-label="Field menu">☰</button>
        </div>
        <b id="location">Kestrel Isle</b>
        <div class="statusline">${ic('storm', 13)}<span id="stext"></span></div>
      </div>
      <div id="compass" class="compass"></div>
      <div class="miniblock glass">
        <canvas id="minimap" width="240" height="240"></canvas>
        <div class="mapline">
          <span>${ic('people')}<b id="alive"></b></span><span>${ic('aim')}<b id="kills"></b></span
          ><span class="hudkey">M</span>
        </div>
      </div>
      <div id="feed" class="feed"></div>
      <div id="reticle" class="reticle"></div>
      <div id="prompt" class="prompt" hidden></div>
      <div id="toast" class="toast"></div>
      <div class="glass vitals">
        <div class="vitalname"><b id="actorname"></b><span id="timber" class="hudlabel"></span></div>
        <div class="bar">
          ${ic('shield')}<i><em id="shieldbar"></em></i><strong id="shield"></strong>
        </div>
        <div class="bar health">
          ${ic('cross')}<i><em id="hpbar"></em></i><strong id="hp"></strong>
        </div>
        <div id="netline" class="netline"></div>
      </div>
      <div class="gear">
        <div class="geartop"><span id="gname"></span><strong id="ammo"></strong></div>
        <div class="slots">
          <button class="slot" data-slot="1" aria-label="Carbine"><b>1</b>${ic('carbine')}</button
          ><button class="slot" data-slot="2" aria-label="Shotgun"><b>2</b>${ic('shotgun')}</button
          ><button class="slot" data-slot="3" aria-label="Shield tonic"><b>3</b>${ic('tonic')}</button>
        </div>
        <div id="gearnote" class="gearnote"></div>
      </div>
      <div id="hint" class="tip">CLICK TO CAPTURE MOUSE &nbsp;·&nbsp; WASD MOVE &nbsp;·&nbsp; Q BUILD</div>
      <button id="cycle" class="specnext" hidden>Next contender →</button>
      <div id="touch">
        <div id="stick"><i></i></div>
        <button class="touchbtn" data-touch="fire">FIRE</button
        ><button class="touchbtn" data-touch="jump">JUMP</button
        ><button class="touchbtn" data-touch="use">USE</button
        ><button class="touchbtn" data-touch="build">BUILD</button
        ><button class="touchbtn" data-touch="reload">RLD</button>
      </div>
    </section>
    <div id="helpbox" class="layer" hidden>
      <div class="dialog">
        <button id="closehelp" class="close" aria-label="Close controls">×</button>
        <div class="over">FIELD MANUAL &nbsp;/&nbsp; 01</div>
        <h2>Controls</h2>
        <div class="controlslist">${controls.map(([k, v]) => '<div><span>' + k + '</span><kbd>' + v + '</kbd></div>').join('')}</div>
      </div>
    </div>
    <div id="maplayer" class="layer" hidden>
      <div id="mapbox" class="dialog">
        <button id="closemap" class="close" aria-label="Close map">×</button>
        <div class="maptitle"><b>Kestrel Isle</b><span class="hudlabel">TACTICAL MAP</span></div>
        <canvas id="bigmap" width="512" height="512"></canvas>
        <div class="smallnote">Gold arrow · Your view &nbsp; / &nbsp; White ring · Next safe zone</div>
      </div>
    </div>
    <div id="result" class="layer" hidden>
      <div class="dialog">
        <div class="over"><i></i> ROUND REPORT &nbsp;/&nbsp; KESTREL ISLE</div>
        <h2 id="resulttitle"></h2>
        <p id="resulttext"></p>
        <button class="primary" id="again">Play again ${ic('arrow')}</button>
        <div class="row">
          <button class="flat" id="spectate">Spectate</button
          ><button class="flat" id="menu">Return to lobby</button>
        </div>
      </div>
    </div>
    <div id="pause" class="layer" hidden>
      <div class="dialog">
        <div class="over">FIELD NETWORK</div>
        <h2>Field menu</h2>
        <p>The round continues while this menu is open.</p>
        <button id="resume" class="primary">Resume ${ic('arrow')}</button>
        <div class="row">
          <button id="pausehelp" class="flat">Controls</button
          ><button id="pausesound" class="flat">Sound</button
          ><button id="quit" class="flat">Leave match</button>
        </div>
      </div>
    </div>
    <div id="fatalbox" class="layer" hidden>
      <div class="dialog">
        <div class="over">GRAPHICS</div>
        <h2>Unable to launch</h2>
        <p id="fatalmsg"></p>
      </div>
    </div>
    <script src="/game.js?matchmaking=2" defer></script>
  </body>
</html>`;
}

function browserGame() {
  'use strict';
  const $ = (id) => document.getElementById(id),
    show = (id, on) => {
      $(id).hidden = !on;
    };
  const text = (id, v) => {
    const e = $(id),
      s = String(v);
    if (e.textContent !== s) e.textContent = s;
  };
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v)),
    lerp = (a, b, t) => a + (b - a) * t;
  const turn = (a, b, t) => a + Math.atan2(Math.sin(b - a), Math.cos(b - a)) * t;
  const now = () => performance.now(),
    canvas = $('world'),
    coarse = matchMedia('(pointer:coarse)').matches;
  let renderer,
    world,
    geo,
    mapImage,
    sim = null,
    latest = null,
    previous = null,
    received = 0,
    roster = [],
    me = -1,
    watch = -1,
    phase = 'menu',
    mode = 'public';
  let session = null,
    pair = null,
    links = new Map(),
    epoch = 0,
    launchTimer = 0,
    simTimer = 0,
    launching = false,
    privateRoom = false,
    lastLobby = null;
  let yaw = 0,
    pitch = -0.15,
    buildMode = false,
    piece = 'wall',
    wantedSlot = 1,
    seq = 0,
    aim = false,
    trigger = false,
    captured = false,
    drag = null,
    predicted = null;
  let effects = [],
    feeds = [],
    toastUntil = 0,
    hitUntil = 0,
    hurtUntil = 0,
    lastVitals = 125,
    lastHud = 0,
    gameAt = 0,
    deadShown = false,
    finalShown = false,
    muted = false,
    audioCtx,
    fromPause = false;
  let inputAt = 0,
    frameAt = 0,
    menuFrame = 0,
    lastPing = 0,
    ping = null,
    queueEnds = 0,
    lastMode = 'practice',
    actionSerial = 0,
    stickX = 0,
    stickZ = 0;
  const keys = new Set(),
    previewSeed = 0x5334a923;
  try {
    muted = localStorage.getItem('bw-mute') === '1';
    $('callsign').value = localStorage.getItem('bw-name') || '';
  } catch {}
  if (!$('callsign').value)
    $('callsign').value = 'Drifter-' + String(Math.floor(Math.random() * 900 + 100));
  function audioState() {
    const label = muted ? 'Sound off' : 'Sound on';
    $('sound').querySelector('span').textContent = label;
    text('pausesound', label);
    $('sound').setAttribute('aria-pressed', String(!muted));
  }
  function wakeAudio() {
    if (muted) return;
    try {
      audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
    } catch {}
  }
  function tone(freq, length, kind = 'sine', vol = 0.045, end = freq) {
    if (muted || !audioCtx || audioCtx.state !== 'running') return;
    const t = audioCtx.currentTime,
      o = audioCtx.createOscillator(),
      g = audioCtx.createGain();
    o.type = kind;
    o.frequency.setValueAtTime(freq, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(20, end), t + length);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + length);
    o.connect(g);
    g.connect(audioCtx.destination);
    o.start(t);
    o.stop(t + length);
  }
  function toggleSound() {
    muted = !muted;
    try {
      localStorage.setItem('bw-mute', muted ? '1' : '0');
    } catch {}
    wakeAudio();
    audioState();
    if (!muted) tone(540, 0.1);
  }
  audioState();
  function buildMap() {
    const c = document.createElement('canvas');
    c.width = c.height = 384;
    const ctx = c.getContext('2d'),
      im = ctx.createImageData(c.width, c.height),
      extent = 308;
    for (let y = 0; y < c.height; y++)
      for (let x = 0; x < c.width; x++) {
        const wx = (x / c.width - 0.5) * extent,
          wz = (0.5 - y / c.height) * extent,
          h = world.ground(wx, wz),
          idx = (y * c.width + x) * 4;
        let color;
        if (h < -0.2) {
          const m = clamp((h + 8) / 8, 0, 1);
          color = [0.14 + m * 0.09, 0.39 + m * 0.15, 0.44 + m * 0.1];
        } else {
          color = world.terrainColor(h, wx, wz);
          const prev = world.ground(wx - 1, wz - 1),
            contour = h > 3 && Math.floor(h / 3) !== Math.floor(prev / 3);
          const shade = contour ? 0.77 : clamp(0.96 + (h - prev) * 0.16, 0.84, 1.15);
          color = color.map((v) => v * shade);
        }
        for (let k = 0; k < 3; k++) im.data[idx + k] = Math.round(color[k] * 255);
        im.data[idx + 3] = 255;
      }
    ctx.putImageData(im, 0, 0);
    const pos = (x, z) => [(x / extent + 0.5) * 384, (0.5 - z / extent) * 384];
    ctx.strokeStyle = '#c0b17d';
    ctx.lineWidth = 2.6;
    ctx.lineJoin = 'round';
    for (const path of world.paths) {
      ctx.beginPath();
      path.forEach(([x, z], i) => (i ? ctx.lineTo(...pos(x, z)) : ctx.moveTo(...pos(x, z))));
      ctx.stroke();
    }
    ctx.fillStyle = '#234f45';
    for (const t of world.trees) {
      const [x, y] = pos(t.x, t.z);
      ctx.fillRect(x, y, 1.6, 1.6);
    }
    ctx.fillStyle = '#efe1b6';
    for (const o of world.props.filter((o) => o.type === 'cabin' || o.type === 'light')) {
      const [x, y] = pos(o.x, o.z);
      ctx.fillRect(x - 2, y - 2, 4, 4);
    }
    ctx.strokeStyle = '#f0f0d626';
    ctx.lineWidth = 1;
    for (let i = 1; i < 8; i++) {
      const s = i * 48;
      ctx.beginPath();
      ctx.moveTo(s, 0);
      ctx.lineTo(s, 384);
      ctx.moveTo(0, s);
      ctx.lineTo(384, s);
      ctx.stroke();
    }
    mapImage = c;
  }
  function setWorld(seed) {
    if (world && world.seed === seed) return;
    world = makeIsland(seed);
    geo = makeMechanics(world);
    renderer.setWorld(world);
    buildMap();
  }
  try {
    renderer = makeRenderer(canvas);
    setWorld(previewSeed);
  } catch (e) {
    text('fatalmsg', e.message);
    show('fatalbox', true);
    return;
  }
  canvas.addEventListener('webglcontextlost', (e) => {
    e.preventDefault();
    text('fatalmsg', 'Graphics context lost. Reload this page to reconnect.');
    show('fatalbox', true);
  });
  const sessionName = () => $('callsign').value.trim().slice(0, 16) || 'Drifter';
  function rememberName() {
    try {
      localStorage.setItem('bw-name', sessionName());
    } catch {}
  }
  async function post(path, data, keepalive = false, controller = new AbortController()) {
    const url = '/api/' + path;
    const timeout = setTimeout(() => controller.abort(), 15000);
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
        signal: controller.signal,
        keepalive,
      });
      const obj = await res.json().catch(() => null);
      if (!res.ok || !obj || typeof obj !== 'object') {
        const message = obj?.error || ('HTTP ' + res.status + ' at ' + url + '. Check the game server or tunnel.');
        throw Object.assign(new Error(message), { status: res.status });
      }
      return obj;
    } catch (e) {
      if (controller.signal.aborted) throw Error('Matchmaker timed out at ' + url + '. Check the server or tunnel and try again.');
      if (e instanceof TypeError) throw Error('Could not reach ' + url + '. Check the server or tunnel and try again.');
      throw e;
    } finally {
      clearTimeout(timeout);
    }
  }
  const credentials = (s) => ({ id: s.id, token: s.token });
  function sendToServer(path, data = {}, s = session) {
    return s ? post(path, { ...credentials(s), ...data }) : Promise.reject(Error('Session ended.'));
  }
  function send(channel, data, fast = false) {
    if (!channel || channel.readyState !== 'open' || (fast && channel.bufferedAmount > 48000)) return false;
    try {
      channel.send(typeof data === 'string' ? data : JSON.stringify(data));
      return true;
    } catch {
      return false;
    }
  }
  function menuBlock(which, msg = '') {
    show('home', which === 'home');
    show('privatebox', which === 'private');
    show('queue', which === 'queue');
    text('lobbymsg', msg);
  }
  function clearKeys() {
    keys.clear();
    trigger = false;
    aim = false;
    stickX = stickZ = 0;
    drag = null;
    $('stick').firstElementChild.style.transform = '';
  }
  function releaseMouse() {
    if (document.pointerLockElement === canvas) {
      try {
        document.exitPointerLock();
      } catch {}
    }
  }
  function closeLink(l) {
    clearTimeout(l.grace);
    l.closed = true;
    try {
      l.pc.close();
    } catch {}
  }
  function reset(msg = '') {
    epoch++;
    clearTimeout(launchTimer);
    clearInterval(simTimer);
    launching = false;
    const old = session;
    session = null;
    old?.poll?.abort();
    if (old) post('leave', credentials(old), true).catch(() => {});
    for (const l of links.values()) closeLink(l);
    links = new Map();
    pair = null;
    lastLobby = null;
    privateRoom = false;
    phase = 'menu';
    sim = null;
    latest = previous = predicted = null;
    roster = [];
    me = watch = -1;
    clearKeys();
    releaseMouse();
    for (const id of ['game', 'result', 'pause', 'maplayer', 'helpbox', 'cycle']) show(id, false);
    show('landing', true);
    $('effect').style.background = 'transparent';
    menuBlock('home', msg);
  }
  function lobbyEvent(data) {
    lastLobby = data;
    privateRoom = data.private;
    queueEnds = now() + data.wait;
    text('qtitle', data.private ? 'Private room' : 'Finding a match');
    text('rcode', data.private ? data.code : '');
    show('launch', data.private && data.host === session.id);
    text(
      'qstatus',
      data.private
        ? data.host === session.id
          ? 'Share this code, then launch when everyone is here.'
          : 'Waiting for the room host to launch.'
        : 'Looking for contenders…',
    );
    $('roster').replaceChildren(
      ...data.players.map((p) => {
        const el = document.createElement('span');
        el.className = 'chip';
        el.textContent = p.name + (p.id === session.id ? ' · YOU' : '');
        return el;
      }),
    );
  }
  async function receiveUpdates(s) {
    let events = s.events;
    let after = 0, failures = 0, lastSuccess = now();
    if (!Array.isArray(events) || events[0]?.type !== 'lobby')
      throw Error('The server did not return a lobby. Restart the updated Breakwater server and reload the page.');

    while (session === s) {
      for (const event of events) {
        if (event.seq !== after + 1) throw Error('Missed a matchmaking update. Please join again.');
        serverEvent(event.type, event.data);
        after = event.seq;
        if (session !== s) return;
      }
      s.poll = new AbortController();
      try {
        const batch = await post('poll', { ...credentials(s), after }, false, s.poll);
        if (!Array.isArray(batch.events)) throw Error('The server returned an invalid lobby update.');
        events = batch.events;
        lastSuccess = now();
        if (session === s && failures) text('lobbymsg', '');
        failures = 0;
      } catch (e) {
        if (session !== s) return;
        const terminal = [400, 401, 403, 404, 409, 410].includes(e.status);
        if (terminal || now() - lastSuccess >= 30000) {
          // An established game can keep using its data channels if signaling goes offline.
          if (phase === 'play') return;
          throw e;
        }
        text('lobbymsg', 'Matchmaker connection interrupted. Retrying…');
        events = [];
        await new Promise((resolve) => setTimeout(resolve, Math.min(4000, 500 * 2 ** failures)));
        failures++;
      }
    }
  }
  async function join(modeWanted, code = '') {
    rememberName();
    wakeAudio();
    reset();
    lastMode = 'public';
    mode = modeWanted;
    phase = 'queue';
    const run = epoch;
    menuBlock('queue');
    text('qtitle', 'Contacting matchmaker');
    text('qstatus', 'Requesting a lobby…');
    text('rcode', '');
    $('roster').replaceChildren();
    show('launch', false);
    if (typeof RTCPeerConnection !== 'function') {
      reset(
        'WebRTC is unavailable here. Try localhost or HTTPS in a WebRTC-capable browser. Solo practice is available.',
      );
      return;
    }
    try {
      const s = await post('join', { mode: modeWanted, code, name: sessionName() });
      if (epoch !== run) {
        post('leave', credentials(s), true).catch(() => {});
        return;
      }
      session = s;
      await receiveUpdates(s);
    } catch (e) {
      if (epoch === run) {
        reset();
        menuBlock(modeWanted === 'code' ? 'private' : 'home', e.message);
      }
    }
  }
  function serverEvent(type, d) {
    if (type === 'lobby' && phase === 'queue') {
      lobbyEvent(d);
      return;
    }
    if (type === 'closed') {
      reset(d.reason);
      return;
    }
    if (type === 'depart') {
      const l = links.get(d.id);
      if (l) {
        closeLink(l);
        links.delete(d.id);
      }
      if (pair) pair.players = pair.players.filter((p) => p.id !== d.id);
      if (sim) sim.disconnect(roster.findIndex((p) => p.id === d.id));
      if (phase === 'links') checkReady();
      return;
    }
    if (type === 'pair' && phase === 'queue') {
      phase = 'links';
      pair = d;
      show('launch', false);
      text('qtitle', 'Linking contenders');
      text('qstatus', 'Negotiating direct WebRTC channels…');
      if (d.host === session.id) {
        for (const p of d.players)
          if (p.id !== session.id) {
            const link = peer(p.id, true);
            (async () => {
              const offer = await link.pc.createOffer();
              await link.pc.setLocalDescription(offer);
              await signal(link, { description: link.pc.localDescription.toJSON() });
            })().catch(() => {});
          }
        launchTimer = setTimeout(startHost, 19000);
        checkReady();
      } else peer(d.host, false);
      return;
    }
    if (type === 'wire' && pair) {
      const l = links.get(d.from);
      if (!l || l.closed) return;
      l.chain = l.chain
        .then(async () => {
          if (l.closed) return;
          if (d.signal.description) {
            await l.pc.setRemoteDescription(d.signal.description);
            for (const c of l.ice) await l.pc.addIceCandidate(c);
            l.ice = [];
            if (d.signal.description.type === 'offer') {
              const answer = await l.pc.createAnswer();
              await l.pc.setLocalDescription(answer);
              await signal(l, { description: l.pc.localDescription.toJSON() });
            }
          } else if (l.pc.remoteDescription) await l.pc.addIceCandidate(d.signal.candidate);
          else l.ice.push(d.signal.candidate);
        })
        .catch(() => {
          if (!l.closed && phase === 'links')
            text('qstatus', 'Negotiating network paths. Waiting for ICE…');
        });
    }
  }
  function signal(link, d) {
    if (!session || link.closed) return Promise.resolve();
    return sendToServer('signal', { to: link.id, signal: d });
  }
  function peer(id, hostSide) {
    const pc = new RTCPeerConnection(session.ice);
    const l = {
      id,
      pc,
      hostSide,
      ice: [],
      chain: Promise.resolve(),
      ctrl: null,
      fast: null,
      closed: false,
      grace: 0,
      aSeq: -1,
      rateAt: 0,
      rate: 0,
    };
    links.set(id, l);
    pc.onicecandidate = (e) => {
      if (e.candidate) signal(l, { candidate: e.candidate.toJSON() }).catch(() => {});
    };
    function lost() {
      if (l.closed || !links.has(id)) return;
      if (phase === 'play') {
        if (!hostSide) {
          reset('Lost the WebRTC connection to the match host. You can queue for another round.');
          return;
        }
        if (sim) sim.disconnect(roster.findIndex((p) => p.id === id));
        closeLink(l);
        links.delete(id);
      }
    }
    pc.onconnectionstatechange = () => {
      if (l.closed) return;
      clearTimeout(l.grace);
      if (pc.connectionState === 'failed') lost();
      if (pc.connectionState === 'disconnected') l.grace = setTimeout(lost, 10000);
    };
    function wire(ch) {
      if (ch.label !== 'control' && ch.label !== 'frames') {
        ch.close();
        return;
      }
      const fast = ch.label === 'frames';
      if (fast) l.fast = ch;
      else l.ctrl = ch;
      ch.onopen = () => checkReady();
      ch.onclose = () => {
        if (!l.closed && phase === 'play') lost();
      };
      ch.onmessage = (e) => {
        if (l.closed || typeof e.data !== 'string' || e.data.length > (hostSide ? 1400 : 64000)) return;
        try {
          const m = JSON.parse(e.data);
          if (m && typeof m === 'object') peerMessage(l, m, fast);
        } catch {}
      };
    }
    pc.ondatachannel = (e) => wire(e.channel);
    if (hostSide) {
      wire(pc.createDataChannel('control', { ordered: true }));
      wire(pc.createDataChannel('frames', { ordered: false, maxRetransmits: 0 }));
    }
    return l;
  }
  const ready = (l) => l && !l.closed && l.ctrl?.readyState === 'open' && l.fast?.readyState === 'open';
  function checkReady() {
    if (phase !== 'links' || !session || pair.host !== session.id || launching) return;
    const waiting = pair.players.filter((p) => p.id !== session.id && !ready(links.get(p.id)));
    if (!waiting.length) startHost();
    else
      text(
        'qstatus',
        'Connected ' +
          (pair.players.length - 1 - waiting.length) +
          ' / ' +
          (pair.players.length - 1) +
          ' peers. Checking network paths…',
      );
  }
  async function startHost() {
    if (launching || phase !== 'links' || pair.host !== session?.id) return;
    launching = true;
    clearTimeout(launchTimer);
    const s = session,
      seed = pair.seed;
    try {
      const active = [...links.values()].filter(ready).map((l) => l.id);
      const out = await sendToServer('start', { active }, s);
      if (session !== s) return;
      const accepted = new Set(out.players.map((p) => p.id));
      for (const [id, l] of links)
        if (!accepted.has(id)) {
          closeLink(l);
          links.delete(id);
        }
      startAuthority(seed, out.players);
    } catch (e) {
      if (session === s) reset(e.message);
    }
  }
  function startAuthority(seed, humans) {
    setWorld(seed);
    sim = makeSimulation(world, humans);
    const snap = sim.snapshot();
    enterGame(sim.roster, snap, humans[0].id);
    const hello = JSON.stringify({ k: 'start', seed, roster: sim.roster, snap });
    for (const l of links.values()) send(l.ctrl, hello);
    let wall = now(),
      acc = 0,
      counter = 0;
    simTimer = setInterval(() => {
      if (!sim || sim.done) return;
      const t = now();
      acc += Math.min(0.3, (t - wall) / 1000);
      wall = t;
      let stepped = false,
        net = false;
      while (acc >= 1 / 30 && !sim.done) {
        sim.update(1 / 30);
        acc -= 1 / 30;
        stepped = true;
        if (++counter % 2 === 0) net = true;
      }
      if (!stepped) return;
      const snap = sim.snapshot();
      accept(snap);
      if (net || snap.done) {
        const packet = JSON.stringify({ k: 'state', snap });
        for (const l of links.values()) send(snap.done ? l.ctrl : l.fast, packet, !snap.done);
      }
      if (sim.events.length) {
        const list = sim.events.splice(0);
        handleEvents(list);
        const packet = JSON.stringify({ k: 'events', list });
        for (const l of links.values()) send(l.ctrl, packet);
      }
      if (snap.done) clearInterval(simTimer);
    }, 12);
  }
  function practice() {
    rememberName();
    wakeAudio();
    reset();
    lastMode = mode = 'practice';
    startAuthority((Math.random() * 4294967296) >>> 0, [{ id: 'local', name: sessionName() }]);
  }
  function peerMessage(l, m, fast) {
    if (l.hostSide) {
      if (!sim || phase !== 'play') return;
      const idx = roster.findIndex((p) => p.id === l.id);
      if (idx < 0) return;
      if (fast && m.k === 'input') {
        sim.input(idx, m);
        return;
      }
      if (!fast && m.k === 'act' && Number.isSafeInteger(m.seq) && m.seq > l.aSeq) {
        l.aSeq = m.seq;
        if (now() - l.rateAt > 1000) {
          l.rateAt = now();
          l.rate = 0;
        }
        if (++l.rate > 30) return;
        sim.action(idx, m.a, m);
      } else if (!fast && m.k === 'ping' && Number.isFinite(m.t)) send(l.ctrl, { k: 'pong', t: m.t });
    } else {
      if (!fast && m.k === 'start' && phase === 'links') {
        setWorld(m.seed);
        enterGame(m.roster, m.snap, session.id);
        return;
      }
      if (phase !== 'play') return;
      if (m.k === 'state') accept(m.snap);
      else if (!fast && m.k === 'events') handleEvents(m.list);
      else if (!fast && m.k === 'pong') ping = Math.round(clamp(now() - m.t, 0, 9999));
    }
  }
  function enterGame(names, snap, id) {
    roster = names;
    me = names.findIndex((p) => p.id === id);
    watch = me;
    if (me < 0) {
      reset('The host could not assign your contender.');
      return;
    }
    phase = 'play';
    latest = previous = predicted = null;
    seq = 0;
    actionSerial = 0;
    ping = null;
    lastPing = 0;
    buildMode = false;
    piece = 'wall';
    wantedSlot = 1;
    clearKeys();
    yaw = snap.players[me].yaw;
    pitch = snap.players[me].pitch;
    effects = [];
    feeds = [];
    lastVitals = 125;
    hurtUntil = hitUntil = 0;
    deadShown = finalShown = false;
    gameAt = now();
    $('feed').replaceChildren();
    text('toast', '');
    show('landing', false);
    show('game', true);
    show('cycle', false);
    show('result', false);
    show('pause', false);
    show('maplayer', false);
    accept(snap);
    notice('GLIDER DEPLOYED  /  Steer with WASD', 3300);
    if (coarse) notice('GLIDER DEPLOYED  /  Left stick to steer · swipe to look', 3300);
  }
  function accept(s) {
    if (!s || !Array.isArray(s.players) || (latest && s.tick <= latest.tick)) return;
    previous = latest;
    latest = s;
    received = now();
    const p = s.players[me];
    if (!p) return;
    if (previous && p.hp + p.shield < lastVitals) hurtUntil = now() + 225;
    lastVitals = p.hp + p.shield;
    if (previous?.players[me].glide && !p.glide)
      notice('LANDED  /  Find supplies and stay inside the ring', 2400);
    if (p.hp <= 0 && !deadShown) {
      deadShown = true;
      report(false);
    }
    if (s.done && !finalShown) report(true);
  }
  function notice(msg, duration = 1750) {
    text('toast', msg);
    toastUntil = now() + duration;
  }
  function addFeed(str) {
    feeds.unshift({ s: str, t: now() + 5500 });
    feeds = feeds.slice(0, 4);
    updateFeed();
  }
  function updateFeed() {
    $('feed').replaceChildren(
      ...feeds.map((f) => {
        const n = document.createElement('div');
        n.textContent = f.s;
        return n;
      }),
    );
  }
  function handleEvents(list) {
    if (!Array.isArray(list) || !latest) return;
    let confirmed = '';
    for (const e of list) {
      const local = e.who === me;
      if (e.type === 'shot') {
        effects.push({ origin: e.origin, ends: e.ends, t: now() + 95 });
        const p = latest.players[watch] || latest.players[me],
          dist = Math.hypot(p.x - e.origin[0], p.z - e.origin[2]);
        if (dist < 70)
          tone(
            e.weapon === 2 ? 114 : 164,
            e.weapon === 2 ? 0.14 : 0.09,
            'sawtooth',
            (local ? 0.065 : 0.029) / (1 + dist * 0.12),
            36,
          );
        if (local && playing())
          pitch = clamp(pitch + (e.weapon === 2 ? 0.022 : 0.005) * (aim ? 0.65 : 1), -1.22, 0.89);
        if (local && e.damage > 0) {
          hitUntil = now() + 190;
          notice(e.damage + ' DAMAGE', 620);
          tone(780, 0.065, 'sine', 0.026, 1060);
        }
      } else if (e.type === 'elim') {
        const who = roster[e.who]?.name || 'Contender',
          by = roster[e.by]?.name;
        addFeed(
          by
            ? by + ' eliminated ' + who
            : who + (e.why === 'disconnect' ? ' disconnected' : ' fell to the storm'),
        );
        if (e.by === me) {
          confirmed = 'ELIMINATED  /  ' + who;
          tone(690, 0.19, 'triangle', 0.07, 980);
        }
      } else if (local && ['loot', 'harvest', 'tonic', 'note'].includes(e.type)) {
        notice(e.text);
        if (e.type !== 'note') tone(490, 0.16, 'triangle', 0.06, 770);
      } else if (local && e.type === 'build') tone(156, 0.105, 'triangle', 0.07, 76);
    }
    if (confirmed) notice(confirmed, 2300);
  }
  function report(final) {
    if (!latest) return;
    const p = latest.players[me],
      won = latest.winner === me;
    if (final) finalShown = true;
    show('result', true);
    show('pause', false);
    show('maplayer', false);
    show('cycle', false);
    clearKeys();
    releaseMouse();
    text(
      'resulttitle',
      final && won ? 'Victory on the isle.' : p.rank ? 'Placed #' + p.rank : 'Round complete.',
    );
    const name = roster[latest.winner]?.name;
    text(
      'resulttext',
      (final
        ? won
          ? 'Last contender standing. '
          : name
            ? name + ' took the island. '
            : 'The storm claimed the island. '
        : 'Your drop has ended. ') +
        p.kills +
        ' elimination' +
        (p.kills === 1 ? '' : 's') +
        ' · ' +
        formatTime(latest.time) +
        ' on the island.',
    );
    show('spectate', !final);
    text('again', lastMode === 'practice' ? 'Practice again →' : 'Find next match →');
    if (won) tone(620, 0.35, 'triangle', 0.06, 1100);
  }
  function nextWatch() {
    if (!latest) return;
    for (let n = 1; n <= roster.length; n++) {
      const i = (watch + n) % roster.length;
      if (latest.players[i].hp > 0) {
        watch = i;
        break;
      }
    }
    yaw = latest.players[watch].yaw;
    pitch = -0.16;
  }
  function unobstructed() {
    return (
      phase === 'play' &&
      $('pause').hidden &&
      $('result').hidden &&
      $('maplayer').hidden &&
      $('helpbox').hidden
    );
  }
  function playing() {
    return unobstructed() && latest && latest.players[me].hp > 0 && !latest.done;
  }
  function axes() {
    if (!playing()) return { mx: 0, mz: 0, sprint: false, fire: false, zoom: false };
    return {
      mx: clamp((keys.has('KeyD') ? 1 : 0) - (keys.has('KeyA') ? 1 : 0) + stickX, -1, 1),
      mz: clamp((keys.has('KeyW') ? 1 : 0) - (keys.has('KeyS') ? 1 : 0) + stickZ, -1, 1),
      sprint: keys.has('ShiftLeft') || keys.has('ShiftRight') || Math.hypot(stickX, stickZ) > 0.89,
      fire: trigger && !buildMode && wantedSlot !== 3,
      zoom: aim && !buildMode,
    };
  }
  function pushInput() {
    if (phase !== 'play' || !latest || !latest.players[me].hp || latest.done) return;
    const input = { k: 'input', seq: ++seq, ...axes(), yaw, pitch };
    inputAt = now();
    if (sim) sim.input(me, input);
    else send(links.get(pair?.host)?.fast, input, true);
  }
  function act(a, extra = {}) {
    if (!playing()) return;
    const m = { k: 'act', a, seq: ++actionSerial, yaw, pitch, ...extra };
    if (sim) sim.action(me, a, m);
    else send(links.get(pair?.host)?.ctrl, m);
    if (!sim && a === 'jump' && predicted?.onGround) {
      predicted.vy = 8.1;
      predicted.onGround = false;
    }
  }
  function selectSlot(i) {
    if (!playing()) return;
    buildMode = false;
    trigger = false;
    wantedSlot = i;
    act('equip', { slot: i });
    pushInput();
  }
  function startFire() {
    if (!playing()) return;
    wakeAudio();
    if (buildMode) act(piece);
    else if (wantedSlot === 3) act('shield');
    else {
      trigger = true;
      pushInput();
      act('fire');
    }
  }
  function stopFire() {
    if (trigger) {
      trigger = false;
      pushInput();
    }
  }
  function toggleBuild(kind) {
    if (!playing()) return;
    buildMode = kind ? true : !buildMode;
    if (kind) piece = kind;
    trigger = false;
    aim = false;
    pushInput();
    if (buildMode) notice('BUILD MODE  /  Z wall · X ramp · C floor', 1400);
  }
  function look(dx, dy) {
    if (!unobstructed()) return;
    const sens = aim ? 0.00165 : 0.003;
    yaw += dx * sens;
    pitch = clamp(pitch - dy * sens, -1.22, 0.89);
  }
  function formatTime(s) {
    s = Math.max(0, Math.floor(s));
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  }
  function drawMap(target, snap, p, large) {
    const ctx = target.getContext('2d'),
      size = target.width,
      e = 308,
      px = (x) => (x / e + 0.5) * size,
      py = (z) => (0.5 - z / e) * size;
    ctx.clearRect(0, 0, size, size);
    ctx.drawImage(mapImage, 0, 0, size, size);
    const st = snap.storm;
    ctx.fillStyle = '#63488652';
    ctx.beginPath();
    ctx.rect(0, 0, size, size);
    ctx.arc(px(st.x), py(st.z), Math.max(0.2, (st.r / e) * size), 0, Math.PI * 2, true);
    ctx.fill('evenodd');
    function ring(x, z, r, color, dash) {
      ctx.save();
      ctx.setLineDash(dash);
      ctx.strokeStyle = color;
      ctx.lineWidth = large ? 2.4 : 2;
      ctx.beginPath();
      ctx.arc(px(x), py(z), Math.max(0.5, (r / e) * size), 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
    ring(st.x, st.z, st.r, '#cba9ff', []);
    ring(st.nx, st.nz, st.nr, '#f5f0dc', large ? [6, 4] : [4, 3]);
    ctx.fillStyle = '#f3f1dc';
    ctx.textAlign = 'left';
    ctx.font = 'bold ' + (large ? 14 : 15) + 'px monospace';
    ctx.fillText('N', size * 0.035, size * 0.085);
    if (large) {
      ctx.font = 'bold 12px monospace';
      ctx.textAlign = 'center';
      for (const loc of world.pois) {
        const x = px(loc.x),
          y = py(loc.z);
        ctx.fillStyle = '#153638c9';
        ctx.fillRect(
          x - ctx.measureText(loc.name).width / 2 - 3,
          y + 3,
          ctx.measureText(loc.name).width + 6,
          15,
        );
        ctx.fillStyle = '#f1edd8';
        ctx.fillText(loc.name, x, y + 14);
      }
    }
    ctx.save();
    ctx.translate(px(p.x), py(p.z));
    ctx.rotate(yaw);
    ctx.fillStyle = '#ffce67';
    ctx.strokeStyle = '#263f41';
    ctx.lineWidth = 2;
    const r = large ? 9 : 7;
    ctx.beginPath();
    ctx.moveTo(0, -r * 1.5);
    ctx.lineTo(r, r);
    ctx.lineTo(0, r * 0.54);
    ctx.lineTo(-r, r);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();
  }
  function openMap() {
    if (phase !== 'play' || !$('result').hidden || !$('helpbox').hidden) return;
    const wasOpen = !$('maplayer').hidden;
    show('maplayer', !wasOpen);
    show('pause', false);
    clearKeys();
    pushInput();
    if (!wasOpen) {
      releaseMouse();
      drawMap($('bigmap'), latest, latest.players[watch], true);
    }
  }
  function fieldMenu() {
    if (phase !== 'play' || !$('result').hidden) return;
    show('maplayer', false);
    show('pause', true);
    clearKeys();
    pushInput();
    releaseMouse();
  }
  let lockFailed = false;
  function capture() {
    if (coarse || lockFailed || !playing() || !canvas.requestPointerLock) return false;
    try {
      const r = canvas.requestPointerLock();
      if (r && r.catch)
        r.catch(() => {
          lockFailed = true;
          notice('Drag to look, or use arrow keys. Enter fires.', 2500);
        });
      return true;
    } catch {
      lockFailed = true;
      return false;
    }
  }
  function wireUI() {
    $('find').onclick = () => join('public');
    $('practice').onclick = practice;
    $('private').onclick = () => menuBlock('private');
    $('back').onclick = () => menuBlock('home');
    $('create').onclick = () => join('create');
    $('joincode').onclick = () => join('code', $('roominput').value);
    $('roominput').onkeydown = (e) => {
      if (e.key === 'Enter') $('joincode').click();
    };
    $('callsign').onkeydown = (e) => {
      if (e.key === 'Enter') $('find').click();
    };
    $('launch').onclick = () => {
      const s = session;
      sendToServer('launch').catch((e) => {
        if (session === s) text('lobbymsg', e.message);
      });
    };
    $('cancel').onclick = () => reset();
    $('sound').onclick = $('pausesound').onclick = toggleSound;
    $('help').onclick = () => {
      fromPause = false;
      show('helpbox', true);
    };
    $('pausehelp').onclick = () => {
      fromPause = true;
      show('pause', false);
      show('helpbox', true);
    };
    $('closehelp').onclick = () => {
      show('helpbox', false);
      if (fromPause && phase === 'play') show('pause', true);
      fromPause = false;
    };
    $('menu').onclick = $('quit').onclick = () => reset();
    $('again').onclick = () => (lastMode === 'practice' ? practice() : join('public'));
    $('spectate').onclick = () => {
      show('result', false);
      nextWatch();
      show('cycle', true);
      notice('SPECTATING', 1100);
    };
    $('cycle').onclick = nextWatch;
    $('fieldmenu').onclick = fieldMenu;
    $('resume').onclick = () => {
      show('pause', false);
      capture();
    };
    $('closemap').onclick = openMap;
    $('minimap').onclick = openMap;
    for (const b of document.querySelectorAll('[data-slot]'))
      b.onclick = () => selectSlot(Number(b.dataset.slot));
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    canvas.addEventListener(
      'wheel',
      (e) => {
        if (!playing()) return;
        e.preventDefault();
        selectSlot(1 + ((wantedSlot - 1 + (e.deltaY > 0 ? 1 : 2)) % 3));
      },
      { passive: false },
    );
    canvas.addEventListener('pointerdown', (e) => {
      if (!unobstructed()) return;
      if (e.pointerType === 'touch') {
        drag = { id: e.pointerId, x: e.clientX, y: e.clientY };
        canvas.setPointerCapture(e.pointerId);
        return;
      }
      if (e.button === 2) {
        aim = true;
        pushInput();
        return;
      }
      if (e.button !== 0) return;
      if (!captured && !lockFailed && !coarse && capture()) return;
      if (!captured) drag = { id: e.pointerId, x: e.clientX, y: e.clientY };
      startFire();
    });
    document.addEventListener('pointermove', (e) => {
      if (captured && e.pointerType !== 'touch') {
        look(e.movementX, e.movementY);
        return;
      }
      if (drag && drag.id === e.pointerId) {
        look((e.clientX - drag.x) * (coarse ? 1.65 : 1), (e.clientY - drag.y) * (coarse ? 1.65 : 1));
        drag.x = e.clientX;
        drag.y = e.clientY;
      }
    });
    document.addEventListener('pointerup', (e) => {
      if (drag?.id === e.pointerId) drag = null;
      if (e.pointerType === 'touch') return;
      if (e.button === 0) stopFire();
      if (e.button === 2) {
        aim = false;
        pushInput();
      }
    });
    document.addEventListener('pointercancel', (e) => {
      if (drag?.id === e.pointerId) drag = null;
      stopFire();
    });
    document.addEventListener('pointerlockchange', () => {
      const old = captured;
      captured = document.pointerLockElement === canvas;
      if (old && !captured) {
        clearKeys();
        pushInput();
        if (unobstructed() && playing()) fieldMenu();
      }
    });
    document.addEventListener('keydown', (e) => {
      if (e.code === 'Escape') {
        if (!$('helpbox').hidden) {
          $('closehelp').click();
          return;
        }
        if (!$('maplayer').hidden) {
          openMap();
          return;
        }
        if (phase === 'play' && $('result').hidden) {
          if (!$('pause').hidden) show('pause', false);
          else fieldMenu();
        }
        return;
      }
      if (phase !== 'play') return;
      if (['Space', 'Tab', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.code))
        e.preventDefault();
      if (e.repeat) return;
      if (e.code === 'KeyM') {
        openMap();
        return;
      }
      if (e.code === 'KeyP') {
        if ($('pause').hidden) fieldMenu();
        else show('pause', false);
        return;
      }
      if (!unobstructed()) return;
      if (e.code === 'Tab' && latest.players[me].hp <= 0) {
        nextWatch();
        return;
      }
      keys.add(e.code);
      if (e.code.startsWith('Digit') && [1, 2, 3].includes(Number(e.code.slice(5))))
        selectSlot(Number(e.code.slice(5)));
      const actions = { Space: 'jump', KeyR: 'reload', KeyE: 'open', KeyF: 'harvest' };
      if (actions[e.code]) act(actions[e.code]);
      if (e.code === 'KeyQ') toggleBuild();
      if (e.code === 'KeyZ') toggleBuild('wall');
      if (e.code === 'KeyX') toggleBuild('ramp');
      if (e.code === 'KeyC') toggleBuild('floor');
      if (e.code === 'Enter') startFire();
      pushInput();
    });
    document.addEventListener('keyup', (e) => {
      keys.delete(e.code);
      if (e.code === 'Enter') stopFire();
      if (phase === 'play') pushInput();
    });
    window.addEventListener('blur', () => {
      clearKeys();
      pushInput();
    });
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        clearKeys();
        pushInput();
      }
    });
    window.addEventListener('pagehide', () => {
      if (session)
        navigator.sendBeacon(
          '/api/leave',
          new Blob([JSON.stringify(credentials(session))], { type: 'application/json' }),
        );
    });
    const stick = $('stick');
    let finger = null;
    function slide(e) {
      const r = stick.getBoundingClientRect(),
        x = (e.clientX - r.left - r.width / 2) / (r.width * 0.36),
        z = (r.top + r.height / 2 - e.clientY) / (r.height * 0.36),
        m = Math.max(1, Math.hypot(x, z));
      stickX = x / m;
      stickZ = z / m;
      stick.firstElementChild.style.transform = 'translate(' + stickX * 23 + 'px,' + -stickZ * 23 + 'px)';
      pushInput();
    }
    stick.onpointerdown = (e) => {
      finger = e.pointerId;
      stick.setPointerCapture(finger);
      slide(e);
    };
    stick.onpointermove = (e) => {
      if (e.pointerId === finger) slide(e);
    };
    stick.onpointerup = stick.onpointercancel = (e) => {
      if (e.pointerId === finger) {
        finger = null;
        stickX = stickZ = 0;
        stick.firstElementChild.style.transform = '';
        pushInput();
      }
    };
    for (const b of document.querySelectorAll('[data-touch]')) {
      b.onpointerdown = (e) => {
        e.preventDefault();
        b.setPointerCapture(e.pointerId);
        const a = b.dataset.touch;
        if (a === 'fire') startFire();
        else if (a === 'build') {
          if (!buildMode) toggleBuild('wall');
          else if (piece === 'wall') toggleBuild('ramp');
          else if (piece === 'ramp') toggleBuild('floor');
          else toggleBuild();
        } else if (a === 'use') {
          const p = latest.players[me];
          if (
            world.caches.some(
              (c) => !latest.opened.includes(c.id) && Math.hypot(p.x - c.x, p.z - c.z) < 3.25,
            )
          )
            act('open');
          else act('harvest');
        } else act(a);
      };
      b.onpointerup = b.onpointercancel = () => {
        if (b.dataset.touch === 'fire') stopFire();
      };
    }
  }
  function updateHud(t, frame) {
    const p = latest.players[me],
      w = frame.players[watch],
      s = latest.storm;
    const heading = ((Math.round((yaw * 180) / Math.PI) % 360) + 360) % 360,
      dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    text(
      'compass',
      '·  ' +
        dirs[(Math.round(heading / 45) + 7) % 8] +
        '   |   ' +
        String(heading).padStart(3, '0') +
        '° ' +
        dirs[Math.round(heading / 45) % 8] +
        '   |   ' +
        dirs[(Math.round(heading / 45) + 1) % 8] +
        '  ·',
    );
    const loc = world.pois.find((o) => Math.hypot(o.x - w.x, o.z - w.z) < 25);
    text(
      'location',
      loc ? loc.name.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase()) : 'Kestrel Isle',
    );
    text(
      'stext',
      (s.phase === 6 ? 'Final tide' : s.moving ? 'Storm closing' : 'Storm in') +
        (s.phase === 6 ? '' : ' ' + formatTime(s.left)),
    );
    text('alive', latest.players.filter((a) => a.hp > 0).length);
    text('kills', p.kills);
    text('actorname', watch === me ? roster[me].name : 'Watching ' + roster[watch].name);
    text('timber', w.wood + ' TIMBER');
    text('hp', w.hp);
    text('shield', w.shield);
    $('hpbar').style.width = w.hp + '%';
    $('shieldbar').style.width = w.shield + '%';
    text(
      'netline',
      mode === 'practice'
        ? 'LOCAL PRACTICE  /  11 BOTS'
        : sim
          ? 'MATCH HOST  /  ' + (1 + [...links.values()].filter(ready).length) + ' HUMAN(S)'
          : 'WEBRTC PEER  /  ' + (ping === null ? 'LINKED' : ping + ' MS RTT'),
    );
    const slot = w.slot,
      mag = slot === 1 ? w.mag : w.shells,
      res = slot === 1 ? w.reserve : w.spare;
    const tier = ['FIELD', 'TUNED', 'ELITE'][slot === 1 ? w.rifleTier : w.shotTier];
    text(
      'gname',
      buildMode
        ? 'FIELD CONSTRUCTION'
        : slot === 1
          ? tier + ' CARBINE'
          : slot === 2
            ? tier + ' BREAKER'
            : 'SHIELD TONIC',
    );
    text('ammo', buildMode ? piece.toUpperCase() : slot === 3 ? '×' + w.pots : mag + ' / ' + res);
    text(
      'gearnote',
      buildMode
        ? '10 TIMBER  ·  Q EXIT BUILD'
        : w.reload
          ? 'RELOADING  ' + w.reload.toFixed(1) + 's'
          : w.drink
            ? 'DRINKING  ' + w.drink.toFixed(1) + 's'
            : slot === 3
              ? 'USE TO RESTORE 45 SHIELD'
              : 'R  RELOAD  ·  Q  BUILD',
    );
    for (const b of document.querySelectorAll('[data-slot]'))
      b.classList.toggle('sel', !buildMode && Number(b.dataset.slot) === slot);
    let prompt = '';
    if (p.hp > 0 && !latest.done) {
      if (w.glide) prompt = coarse ? 'STEER YOUR GLIDER' : 'WASD  /  STEER GLIDER';
      else if (buildMode)
        prompt = coarse
          ? 'FIRE  /  PLACE ' + piece.toUpperCase()
          : 'CLICK  /  PLACE ' + piece.toUpperCase();
      else if (
        world.caches.some(
          (c) =>
            !latest.opened.includes(c.id) &&
            Math.hypot(c.x - w.x, c.z - w.z) < 3.25 &&
            Math.abs(c.y - w.y) < 3.2,
        )
      )
        prompt = coarse ? 'USE  /  OPEN SUPPLY CRATE' : 'E  /  OPEN SUPPLY CRATE';
      else if (world.trees.some((o) => Math.hypot(o.x - w.x, o.z - w.z) < 3.25 && Math.abs(o.y - w.y) < 3))
        prompt = coarse ? 'USE  /  HARVEST TIMBER' : 'F  /  HARVEST TIMBER';
    }
    text('prompt', prompt);
    show('prompt', !!prompt);
    show('reticle', p.hp > 0 && !w.glide);
    $('reticle').classList.toggle('hit', t < hitUntil);
    if (t > toastUntil) text('toast', '');
    if (feeds.some((f) => f.t < t)) {
      feeds = feeds.filter((f) => f.t >= t);
      updateFeed();
    }
    show('hint', !coarse && p.hp > 0 && !latest.done && (!captured || t - gameAt < 11500));
    text(
      'hint',
      captured
        ? 'SHIFT SPRINT  ·  E LOOT  ·  F HARVEST  ·  M MAP'
        : lockFailed
          ? 'DRAG OR ARROWS TO LOOK  ·  ENTER FIRE  ·  P MENU'
          : 'CLICK TO CAPTURE MOUSE  ·  WASD MOVE  ·  P MENU',
    );
    const outside = Math.hypot(w.x - s.x, w.z - s.z) > s.r;
    $('effect').style.background =
      t < hurtUntil
        ? 'radial-gradient(ellipse at center,transparent 32%,#c4383c72)'
        : outside
          ? 'radial-gradient(ellipse at center,#7756b518,#7959c85b)'
          : 'transparent';
    drawMap($('minimap'), latest, w, false);
    if (!$('maplayer').hidden) drawMap($('bigmap'), latest, w, true);
  }
  function frameState(t, dt) {
    const a = latest,
      b = previous,
      interval = b ? Math.max(0.015, a.time - b.time) : 0.066,
      ratio = clamp((t - received) / (interval * 1000), 0, 1);
    const players = a.players.map((p, i) => {
      const old = b?.players[i];
      if (!old || !p.hp) return { ...p };
      return {
        ...p,
        x: lerp(old.x, p.x, ratio),
        y: lerp(old.y, p.y, ratio),
        z: lerp(old.z, p.z, ratio),
        yaw: turn(old.yaw, p.yaw, ratio),
      };
    });
    if (!sim && a.players[me].hp > 0 && !a.done) {
      const auth = a.players[me],
        old = b?.players[me],
        controls = axes();
      if (!predicted || Math.hypot(predicted.x - auth.x, predicted.y - auth.y, predicted.z - auth.z) > 4)
        predicted = { ...auth, vy: 0, onGround: !auth.glide };
      predicted.yaw = yaw;
      predicted.glide = auth.glide;
      geo.move(predicted, controls, dt, a.builds);
      const ahead = clamp((t - received) / 1000 + (ping || 0) / 2000, 0, 0.13);
      for (const k of ['x', 'z', 'y']) {
        const velocity = old ? clamp((auth[k] - old[k]) / interval, -22, 22) : 0;
        const dest = auth[k] + velocity * ahead;
        predicted[k] = lerp(predicted[k], dest, 1 - Math.exp(-dt * (k === 'y' ? 12 : 8)));
        players[me][k] = predicted[k];
      }
    }
    if (a.players[me].hp > 0) {
      players[me].yaw = yaw;
      players[me].pitch = pitch;
    }
    return { ...a, players };
  }
  function animate(t) {
    requestAnimationFrame(animate);
    const dt = Math.min(0.07, Math.max(0, (t - frameAt) / 1000));
    frameAt = t;
    if (phase !== 'play') {
      if (phase === 'queue' && lastLobby && !privateRoom)
        text(
          'qstatus',
          'Drop in ' +
            Math.max(0, Math.ceil((queueEnds - t) / 1000)) +
            's  ·  ' +
            lastLobby.players.length +
            '/8 human seats  ·  remaining spots fill with bots.',
        );
      if (t - menuFrame < 45) return;
      menuFrame = t;
      const theta = -0.63 + 0.07 * Math.sin(t * 0.000043);
      const cam = {
        pos: [9 - Math.sin(theta) * 140, 49 + 2 * Math.sin(t * 0.00008), 15 - Math.cos(theta) * 140],
        yaw: theta,
        pitch: -0.245,
      };
      renderer.render(cam, null, [], null, t / 1000, false);
      return;
    }
    if (!latest) return;
    if (keys.has('ArrowLeft')) yaw -= dt * 1.85;
    if (keys.has('ArrowRight')) yaw += dt * 1.85;
    if (keys.has('ArrowUp')) pitch = clamp(pitch + dt * 1.15, -1.22, 0.89);
    if (keys.has('ArrowDown')) pitch = clamp(pitch - dt * 1.15, -1.22, 0.89);
    if (t - inputAt >= 40) pushInput();
    if (!sim && t - lastPing > 2000) {
      send(links.get(pair?.host)?.ctrl, { k: 'ping', t });
      lastPing = t;
    }
    if (watch !== me && !latest.players[watch].hp && !latest.done) nextWatch();
    const frame = frameState(t, dt),
      p = frame.players[watch],
      cam = geo.camera(p, yaw, pitch, frame.builds, aim);
    effects = effects.filter((e) => e.t > t);
    const ghost = buildMode && playing() && !p.glide ? geo.preview({ ...p, yaw }, piece) : null;
    renderer.render(cam, frame, effects, ghost, t / 1000, aim && !buildMode);
    if (t - lastHud > 75) {
      updateHud(t, frame);
      lastHud = t;
    }
  }
  wireUI();
  requestAnimationFrame(animate);
}

if (require.main === module) {
  const server = createMatchmaker(),
    port = Number(process.env.PORT || 3000),
    host = process.env.HOST || '0.0.0.0';
  server.on('error', (err) => {
    console.error('Breakwater could not listen:', err.message);
    process.exitCode = 1;
  });
  server.listen(port, host, () =>
    console.log(
      'Breakwater Royale is listening on ' +
        host +
        ':' +
        server.address().port +
        ' — open http://localhost:' +
        server.address().port,
    ),
  );
}
module.exports = { createMatchmaker, makeIsland, makeMechanics, makeSimulation };
